﻿namespace GenAlgUserControlLib;

[DefaultEvent(nameof(ValueChanged))]
public partial class SliderWithValue : UserControl
{
  public event EventHandler<ValueChangedEventArgs> ValueChanged;
  public SliderWithValue()
  {
    InitializeComponent();
    Step = 1;
  }

  public string Header
  {
    get => lblHeader.Content.ToString();
    set => lblHeader.Content = value;
  }

  public int Val
  {
    get => (int)sldValue.Value;
    set => sldValue.Value = value;
  }

  public int Min
  {
    get => (int)sldValue.Minimum;
    set => sldValue.Minimum = value;
  }

  public int Max
  {
    get => (int)sldValue.Maximum;
    set => sldValue.Maximum = value;
  }

  public int Step
  {
    get => (int)sldValue.TickFrequency;
    set
    {
      sldValue.TickFrequency = value;
      sldValue.LargeChange = value;
      sldValue.SmallChange = value;
    }
  }

  private void SldValue_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
  {
    int iVal = (int)sldValue.Value;
    lblVal.Content = $"{iVal:0}";
    ValueChanged?.Invoke(this, new ValueChangedEventArgs { Val = iVal });
  }
}
