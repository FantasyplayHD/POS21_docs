﻿namespace GenAlgUserControlLib;

public class ValueChangedEventArgs : EventArgs
{
  public int Val { get; set; }
}
