﻿namespace GenAlgRucksackProblem;

class Randomizer
{
  private static Random random = null;
  //public static Random Rnd
  //{
  //  get
  //  {
  //    if (random == null) random = new Random(666);
  //    return random;
  //  }
  //}
  public static Random Rnd => random ??= new(666);
  private Randomizer() { }
}
