﻿namespace GenAlgRucksackproblem;

public partial class App : Application
{
}
