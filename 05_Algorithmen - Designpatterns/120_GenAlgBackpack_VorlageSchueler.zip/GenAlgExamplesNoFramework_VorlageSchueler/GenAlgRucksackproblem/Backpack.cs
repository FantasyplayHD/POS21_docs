﻿namespace GenAlgRucksackProblem;

internal class Backpack
{
  private List<bool> selectionFlags = null;

  #region -------------------------------------------------------------- construct
  public Backpack()
  {
    InitFlagsRandomly();
    Repair();
    CalculateFitness();
  }

  public Backpack(List<bool> selections)
  {
    selectionFlags = new (selections); // make a copy of the selected values
    CalculateFitness();
  }

  private void InitFlagsRandomly()
  {
    selectionFlags = Repository.Items
      .Select(x => Randomizer.Rnd.NextDouble() >= 0.5)
      .ToList();
  }

  public Backpack DeepClone() => new(selectionFlags);
  #endregion

  public int Fitness { get; private set; } = 0;
  private string FlagString => string.Join("", selectionFlags.Select(x => x ? "X" : "_"));
  public override string ToString() => $"{Fitness}: {FlagString}";

  #region -------------------------------------------------------------- helpers
  public int GetCurrentSize() => GetSelectedItems().Sum(x => x.Size);

  private void CalculateFitness() => Fitness = GetSelectedItems().Sum(x => x.Value);

  public List<Item> GetSelectedItems() => Repository.Items.Where((x, i) => selectionFlags[i]).ToList();

  public bool IsSelected(int index) => selectionFlags[index];

  public void SetSelected(int index, bool isUsed) => selectionFlags[index] = isUsed;
  #endregion

  #region -------------------------------------------------------------- main methods
  public void Repair()
  {
	//randomly remove items (i.e. set flag to false) as long total size>capacity
  }

  public void Mutate()
  {
	//randomly toggle a flag in selectionFlags
	//afterwards repair
  }

  public (Backpack, Backpack) CrossOver(Backpack partner)
  {
    Backpack child1 = this.DeepClone();
    Backpack child2 = partner.DeepClone();
	//randomly select crossover point and cross parents
    //don't forget to repair
    return (child1, child2);
  }
  #endregion
}
