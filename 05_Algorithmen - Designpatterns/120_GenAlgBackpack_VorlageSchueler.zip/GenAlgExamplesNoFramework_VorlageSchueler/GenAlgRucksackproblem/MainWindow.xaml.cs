﻿namespace GenAlgRucksackProblem;

public partial class MainWindow : Window
{
  public MainWindow() => InitializeComponent();

  private void Window_Loaded(object sender, RoutedEventArgs e)
  {
    BtnGenerateItems_Click(null, null);
    BtnRatio_Click(null, null);
    BtnGenetic_Click(null, null);
  }

  private void BtnGenerateItems_Click(object sender, RoutedEventArgs e)
  {
    Repository.NrDifferentItems = sldNrItems.Val;
    Repository.BackpackCapacity = sldCapacity.Val;
    Repository.Create(sldSizeMin.Val, sldSizeMax.Val, sldValMin.Val, sldValMax.Val);
    lblGenerated.Content = Repository.AsString();
  }
  private void BtnValue_Click(object sender, RoutedEventArgs e) => lblConventional.Content = AsString(ConventionalAlgos.GetItemsBaseOnValue());
  private void BtnSize_Click(object sender, RoutedEventArgs e) => lblConventional.Content = AsString(ConventionalAlgos.GetItemsBaseOnSize());
  private void BtnRatio_Click(object sender, RoutedEventArgs e) => lblConventional.Content = AsString(ConventionalAlgos.GetItemsBaseOnRatio());

  private void BtnGenetic_Click(object sender, RoutedEventArgs e)
  {
    var engine = new GeneticAlgorithmEngine(
      sldPopulation.Val,
      sldCrossoverPerc.Val,
      sldMutationPerc.Val,
      sldElitismPerc.Val
      );
    var bestBackpack = engine.FindBest();
    var items = bestBackpack.GetSelectedItems();
    lblGenetic.Content = AsString(items);
  }

  private static string AsString(List<Item> items) =>
    $"{items.Count} Items{Environment.NewLine}Total value: {items.Sum(i => i.Value)}{Environment.NewLine}Total size: {items.Sum(i => i.Size)}";

}
