﻿namespace GenAlgRucksackProblem;

class ConventionalAlgos
{

  public static List<Item> GetItemsBaseOnValue()
  {
    //highest values first, then smallest size
    return GetItemsThatFit(new()); //remove this line
    //var sortedList = ...
    //return GetItemsThatFit(sortedList);
  }

  public static List<Item> GetItemsBaseOnSize()
  {
    //smallest items first, then highest value
    return GetItemsThatFit(new()); //remove this line
    //var sortedList = ...
    //return GetItemsThatFit(sortedList);
  }

  public static List<Item> GetItemsBaseOnRatio()
  {
    //relativly valuable first
    return GetItemsThatFit(new()); //remove this line
    //var sortedList = ...
    //return GetItemsThatFit(sortedList);
  }

  private static List<Item> GetItemsThatFit(List<Item> sortedList)
  {
    //put the first x items from sortedList in a new list
    //until Repository.BackpackCapacity is reached 
    //perhaps LINQ method TakeWhile may be helpful

    return sortedList;
  }
}
