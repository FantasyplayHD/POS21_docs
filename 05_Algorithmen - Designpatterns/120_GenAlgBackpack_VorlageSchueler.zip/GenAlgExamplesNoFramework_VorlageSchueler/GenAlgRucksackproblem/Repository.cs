﻿namespace GenAlgRucksackProblem;

class Repository
{
  public static List<Item> Items { get; private set; }

  public static int BackpackCapacity { get; set; }
  public static int NrDifferentItems { get; set; }
  public static int TotalValue => Items.Sum(i => i.Value);
  public static int TotalSize => Items.Sum(i => i.Size);

  public static string AsString() => $"{Items.Count} Items{Environment.NewLine}Total value: {TotalValue}{Environment.NewLine}Total size: {TotalSize}";

  public static void Create(
    int itemSmallestSize, int itemBiggestSize,
    int itemSmallestValue, int itemBiggestValue)
  {
    Items = Enumerable.Range(0, NrDifferentItems)
        .Select(x => new Item
        {
          Size = Randomizer.Rnd.Next(itemSmallestSize, itemBiggestSize + 1),
          Value = Randomizer.Rnd.Next(itemSmallestValue, itemBiggestValue + 1),
        })
        .ToList();
  }

}
