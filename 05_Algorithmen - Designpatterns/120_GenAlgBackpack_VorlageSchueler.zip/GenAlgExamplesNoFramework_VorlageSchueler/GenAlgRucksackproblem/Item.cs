﻿namespace GenAlgRucksackProblem;

public class Item
{
  public int Value { get; set; }
  public int Size { get; set; }
  public double ValueSizeRatio => ((double)Value) / Size;
}
