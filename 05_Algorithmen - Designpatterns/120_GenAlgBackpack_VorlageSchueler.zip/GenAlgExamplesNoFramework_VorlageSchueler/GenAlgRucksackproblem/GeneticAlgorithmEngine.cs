﻿namespace GenAlgRucksackProblem;

internal class GeneticAlgorithmEngine
{
  #region -------------------------------------------------------------- variables + helpers
  private const bool UseTournamentSelection = false;
  private const int nrGenerationsChangeLimit = 100;

  private readonly int populationSize;
  private readonly double crossoverRate;
  private readonly double mutationRate;
  private readonly double elitismRate;
  private readonly int tournamentSize = 10;

  private List<Backpack> currentGeneration;
  private int currentTotalFitness = 0;

  private int bestFitnessAllTime = 0;
  private Backpack bestBackpack = null;
  private int generationNrOfBest = 0;
  private Func<Backpack> SelectCandidate;

  private double GetAverageFitnessCurrentSolution() => currentGeneration.Average(x => x.Fitness);

  private bool ShouldMutate => Randomizer.Rnd.NextDouble() < mutationRate;
  private bool ShouldCrossover => Randomizer.Rnd.NextDouble() < crossoverRate;
  #endregion

  #region -------------------------------------------------------------- constructor + Seed
  public GeneticAlgorithmEngine(int populationSize, int crossoverPercent,
      double mutationPercent, double elitismPercent)
  {
    this.populationSize = populationSize;
    crossoverRate = crossoverPercent / 100D;
    mutationRate = mutationPercent / 100D;
    elitismRate = elitismPercent / 100D;
    SelectCandidate = UseTournamentSelection ? SelectCandidateViaTournament : SelectCandidateByRouletteWheel;
  }
  private void SeedGenerationZero()
  {
    currentGeneration = Enumerable.Range(0, populationSize)
      .Select(x => new Backpack())
      .ToList();
  }
  #endregion

  #region -------------------------------------------------------------- FindBest
  public Backpack FindBest()
  {
    SeedGenerationZero();

    //implement algorithm here
    bestBackpack = currentGeneration.First(); //remove this line

    Console.WriteLine($"Found best solution at generation {generationNrOfBest}: {bestBackpack}");
    return bestBackpack;
  }
  #endregion

  #region -------------------------------------------------------------- Next Generation
  private List<Backpack> CreateNextGeneration()
  {
    var nextGeneration = new List<Backpack>();
    //populate according to algorithm instead of just copying generation
    nextGeneration = new(currentGeneration); //remove this line
    return nextGeneration;
  }

  private Backpack GetBestAndCalculateTotalFitness()
  {
	//calculate total fitness of current generation
	//select individual with best (=highest fitness) and return instead of next line
    return currentGeneration.First(); //remove this line
  }

  private void AddElite(List<Backpack> nextGeneration)
  {
	//add the best individuals of current generation to next generation
	//use elitismRate to calculate the number of the elite
  }

  private bool ShouldTerminate(int generationNr, Backpack bestOfThisGeneration)
  {
	//detect for how many generations no new best indivual is found
	//use nrGenerationsChangeLimit to compare
    return false; //remove this line
  }
  #endregion

  #region -------------------------------------------------------------- Selection
  private Backpack SelectCandidateByRouletteWheel()
  {
	//implement as explained in theory lesson 
    return currentGeneration.First(); //remove this line
  }

  private Backpack SelectCandidateViaTournament()
  {
    // pick N random candidates, and then return the one with the highest fitness
    return currentGeneration.First(); //remove this line
  }
  #endregion
}
