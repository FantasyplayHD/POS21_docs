# MdfViewer

## Getting started
The aim of the GUI "MdfViewer" is to enable the contents of database tables to be viewed as easily and quickly as possible. 
- For this purpose, a button is generated for each table, which displays its content when clicked.
- The database diagram can be displayed in a different window.
- In addition, you can enter SQL queries in a "query" text box, which is supported by autocomplete.
- In the basic version, SQLServer and SQLite databases are available. For other database types (see below), additional DLLs must be copied.

## Main Window
![alt text](http://www.club97.net/images/mdfviewer/main_window.png "Main Window")

In the DataGrid you can 
- edit
- add
- delete

No explicit saving is necessary, i.e. the changes are automatically transferred to the database.
### Features of Main Window
|Feature   |Description |
|:---------|:-----------|
|Query| Here you can enter SQL selects. This is supported by Intellisense (selection with cursor keys or ```<tab>```): ![alt text](http://www.club97.net/images/mdfviewer/query_screenshot.png "Queries")
|Tables| A button is created for each table. If you click on the button, the data is displayed. In case of larger tables, only 50 data records are displayed at first and the others are loaded when scrolling down.
|Status bar| Displays the following: <br>- Number of records <br>- Current ConnectionString <br>- Checkbox to hide the table info
|Table-Info| Shows the short info for all columns of the currently opened table. <br>- The primary key is shown in *italics*.<br>- Identity columns are shown in <span style="color:red">red</span>
|![alt text](http://www.club97.net/images/mdfviewer/icon_open.png "Open Database")|	Opens a database. The path of the last database loaded is saved and proposed the next time. The full file name of the MDF file is displayed next to it.
|Drag&Drop| Instead of "Open", you can also drag a database file onto the window so that its data is displayed.
|Version| Displays the database version of the currently opened database.
|Version Check| If you drag a database file (other than the one currently open) onto the "Version" label, the database version of this file is displayed next to it. The background turns blue. <br> ![alt text](http://www.club97.net/images/mdfviewer/version_screenshot.png "Version Check")
|![alt text](http://www.club97.net/images/mdfviewer/icon_showdiagram.png "Show Diagram")| Show diagram (see below)
|![alt text](http://www.club97.net/images/mdfviewer/icon_execute.png "Execute SQL")| Execute SQL commands (see below)
|![alt text](http://www.club97.net/images/mdfviewer/icon_history.png "SQL History")| History of SQL commands

## Diagram
The database model can be displayed graphically in a separate window. 
![alt text](http://www.club97.net/images/mdfviewer/diagram_window.png "Diagram Window")
The tables are arranged in such a way that as few/short connecting lines as possible are created. 
- Depending on the number of tables, this is done by iterating all permutations or using a genetic algorithm.
- The diagram can be adapted (delete and move tables, as well as zoom with ```<Ctrl>```+mouse wheel)
- The diagram can be printed as a png (the file is saved in the same directory as the database).
- At the beginning, only those tables are displayed that also have relationships/foreign keys to other tables. If you click on "Show all", all tables are taken into account.
- Primary keys are displayed with a blue font at the top of a table 
- Identity columns are displayed in red font
- Foreign keys are displayed with a skyblue background at the bottom.


## SqlExecutor 
Here you can enter several general SQL statements. Click on **Execute** to execute them. In the event of an error, a tooltip is displayed above the error.
**Clear** deletes all entries.

![alt text](http://www.club97.net/images/mdfviewer/sqlexecutor_window.png "SQLExecutor Window")

With "Open SQL-file" you can load a text file with SQL statements.

## SqlHistory 
The last 20 select statements in the query text field are saved (each per open database) and can be executed again:

![alt text](http://www.club97.net/images/mdfviewer/sqlhistory_window.png "SQLHistory Window")

- **Double-click**: Executes statement directly
- **Click**: copies the statement into query text field

## Database types
The following databases are available:
- SqlServer MDF files
- Sqlite files
- Postgres
- MySql

## Version-History
|version   |changes |
|:---------|:-----------|

|7.3.1|	Bugfix: detecting foreign keys in SqlServer (TargetColumn)
|7.3.0|	Bugfix: use schema name for queries in SqlServer
|7.2.3|	Bugfix: detecting foreign keys SQLServer
|7.2.2|	Bugfix: detecting foreign keys
|7.2.1|	ChartOptimizerFactory introduced: Factory method that chooses between permutations and genetic algorithm according to number of tables
|7.2.0|	genetic algorithm introduced for arranging database diagram
|7.1.0| switched to .net6 <br>support for .sdf files cancelled <br>bugfix: insert for non-identity columns now possible <br>bugfix: columns with types like Byte[] now are ignored when generating insert statement
|6.4.1| Detect and display Identity columns in Chart and table description (in red colour, respectively)
|6.3.5| Bugix: ForeignKeys in SQLite: e.g. Kino_KinoId --> KinoKinoId
|6.3.4| Bugfix when recognising existing DLLs
|6.3.3| Icons for buttons
|6.3.2| Performance improvement Auto-Arrange
|6.3.1| Automatically arrange tables so that there are as few/short connecting lines as possible.
|6.2.1| Check if DLLs for database providers are available
|6.2.0| Display Foreign Keys at the end of each table
|6.1.0| Bugfix display database version. <br>Database diagram for Mdf and Sqlite<br/>
|5.2.0| Added access to MySql databases (untested)
|5.1.1| Bugfix for Postgres
|5.1.0| Added access for Postgres databases
|4.2.3| Output lines in SqlExecutor can be scrolled 
|4.2.2| Bugfix: Double click on .sqlite, .db or .sdf now also opens these files
|4.2.1| Bugfix Drag&Drop for Sdf/Sqlite
|4.2.0| Access class for Sqlite database files
|4.1.0| Access class for SqlServer Compact (*.sdf)
|4.0.0| Redesign of DB access classes (preparation for Factory)
|3.6.1| Outputs are now visible when starting from the console. <br>In case of exceptions, all exceptions are displayed.<br/>
