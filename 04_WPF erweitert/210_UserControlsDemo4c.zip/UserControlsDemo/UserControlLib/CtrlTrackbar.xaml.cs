﻿using System;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Media;

namespace UserControlLib;

public partial class CtrlTrackbar : UserControl
{
  public event EventHandler<TrackbarEventArgs> TrackbarChanged;

  public CtrlTrackbar() => InitializeComponent();

  private string title;
  [Category("MyNewProps")]
  public string Title
  {
    get => title;
    set
    {
      title = value;
      lblTitle.Content = value;
    }
  }

  private Brush labelBrush;
  [Category("MyNewProps")]
  public Brush LabelBrush
  {
    get { return labelBrush; }
    set
    {
      labelBrush = value;
      lblTitle.Background = labelBrush;
    }
  }

  private void sliValue_ValueChanged(object sender, System.Windows.RoutedPropertyChangedEventArgs<double> e)
  {
    lblValue.Content = e.NewValue;
    TrackbarChanged?.Invoke(this, new TrackbarEventArgs { Value = e.NewValue });
  }
}
