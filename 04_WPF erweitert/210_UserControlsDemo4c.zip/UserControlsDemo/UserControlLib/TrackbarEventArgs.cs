﻿namespace UserControlLib;

public class TrackbarEventArgs
{
  public double Value { get; set; }
}
