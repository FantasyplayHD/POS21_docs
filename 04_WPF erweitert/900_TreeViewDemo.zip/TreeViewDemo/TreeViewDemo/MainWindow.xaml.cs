﻿using NorthwindDb;

using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace TreeViewDemo;

public partial class MainWindow : Window
{
  private NorthwindContext db;
  public MainWindow()
  {
    InitializeComponent();
    db = new NorthwindContext();
  }

  private void Window_Loaded(object sender, RoutedEventArgs e)
  {
    var categories = db.Categories.ToList();
    foreach (var category in categories)
    {
      var nodeCategory = new TreeViewItem { Header = category };
      trvMain.Items.Add(nodeCategory);
      AddProductsToCategory(category, nodeCategory);
    }
  }

  private void AddProductsToCategory(Category category, TreeViewItem nodeCategory)
  {
    var products = db.Products.Where(x => x.CategoryId == category.CategoryId).ToList();
    foreach (var product in products)
    {
      var nodeProduct = new TreeViewItem { Header = product };
      nodeProduct.Selected += NodeProduct_Selected;
      nodeCategory.Items.Add(nodeProduct);
    }
    nodeCategory.IsExpanded = true;
  }

  private void NodeProduct_Selected(object sender, RoutedEventArgs e)
  {
    var node = sender as TreeViewItem;
    var product = node.Header as Product;
    Console.WriteLine($"Selected Productr {product}");
  }
}
