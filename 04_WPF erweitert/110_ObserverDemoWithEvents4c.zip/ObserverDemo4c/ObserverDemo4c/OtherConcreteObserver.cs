﻿namespace ObserverDemo4c;

internal class OtherConcreteObserver
{
  public OtherConcreteObserver(ConcreteSubject subject)
  {
    subject.Notify += Update;
  }
  public void Update(object sender, ChangeEventArgs e)
  {
    Console.WriteLine($"*********************** {e.State}");
  }
}
