﻿namespace ObserverDemo4c;

internal class ChangeEventArgs : EventArgs
{
  //int state, DateTime clock
  public int State { get; set; }
  public DateTime Clock { get; set; }
  public string Message { get; set; }
  public double MyProperty { get; set; }
}
