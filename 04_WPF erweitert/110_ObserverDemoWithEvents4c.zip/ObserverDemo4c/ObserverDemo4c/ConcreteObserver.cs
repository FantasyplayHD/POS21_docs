﻿namespace ObserverDemo4c;

internal class ConcreteObserver
{
  private static int count = 1;
  private readonly string name;

  public ConcreteObserver(ConcreteSubject subject)
  {
    name = $"Observer_{count++}";
    subject.Notify += Update;
  }

  public void Exit() { }// subject.Notify -= Update;

  public void Update(object sender, ChangeEventArgs e)
  {
    Console.WriteLine($"{DateTime.Now:HH:mm:ss}: {this} --> {e.State}");
  }

  public override string ToString() => name;
}
