﻿using ObserverDemo4c;

var subject = new ConcreteSubject();

var firstObserver = new ConcreteObserver(subject);
var secondObserver = new ConcreteObserver(subject);
var _ = new OtherConcreteObserver(subject);
ConcreteObserver thirdObserver = null;
for (int i = 1; i < 10; i++)
{
  Thread.Sleep(1000);
  subject.State = i;
  if (i == 3) { thirdObserver = new ConcreteObserver(subject); }
  if (i == 5) firstObserver.Exit();
  if (i == 6)
  {
    secondObserver.Exit();
    thirdObserver?.Exit();
  }
}

Console.ReadKey();
