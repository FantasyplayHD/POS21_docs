﻿namespace ObserverDemo4c;

internal class ConcreteSubject
{
  public event EventHandler<ChangeEventArgs>? Notify;
  private int state = 0;

  public int State
  {
    get => state;
    set
    {
      state = value;
      Console.WriteLine($"{DateTime.Now:HH:mm:ss} --> new state {state}");
      Notify?.Invoke(this, new ChangeEventArgs
      {
        State = state,
        Clock = DateTime.Now
      });
    }
  }

}
