﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZeitDb
{
    public class TimeEntry
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }
        public int ProjectId { get; set; }
        public Project Project { get; set; }
        public DateTime From{ get; set; }
        public DateTime To { get; set; }
        public int ActivityId { get; set; }
        public Activity Activity { get; set; }

        public string Description { get; set; }

        public override string ToString() => $"{Employee.Fullname} :: {Project.Name} ( {Activity.Description} ) -> From: {From} To: {To}";
    }
}
