﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZeitDb
{
  public class ZeitDbContext : DbContext
  {
    public ZeitDbContext()
    {

    }

    public ZeitDbContext(DbContextOptions<ZeitDbContext> options) : base(options)
    {

    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
      Console.WriteLine($"Db OnConfiguring: IsConfigured={optionsBuilder.IsConfigured}");
      if (!optionsBuilder.IsConfigured)
      {
        optionsBuilder.UseSqlServer(@"server=(LocalDB)\mssqllocaldb;attachdbfilename=D:\Temp\ZeitDb.mdf;database=ZeitDb;integrated security=TRUE");
      }
      base.OnConfiguring(optionsBuilder);
    }

    public DbSet<Activity> Activities { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Project> Projects { get; set; }
    public DbSet<TimeEntry> TimeEntries { get; set; }


  }
}
