﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Zeitaufzeichnung
{
  public partial class MainWindow : Window
  {

    public MainWindow()
    {
      InitializeComponent();
    }
  }
}
