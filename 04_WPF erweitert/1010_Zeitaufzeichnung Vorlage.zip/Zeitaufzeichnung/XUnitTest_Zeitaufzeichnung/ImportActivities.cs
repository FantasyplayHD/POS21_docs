﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Xunit;
using Zeitaufzeichnung;

namespace XUnitTest_Zeitaufzeichnung
{
  public class ImportActivities
  {
    [Fact]
    public void T01_ImportDataFromCSV()
    {
      Assert.True(false, "Comment in the code of the unit test!");
      //var db = new ZeitDb.ZeitDbContext();
      //new DbSeeder(db).ImportAllCsvFiles();
	  
      //int nrTimeEntriesInDb = db.TimeEntries.Count();
      //Assert.Equal(1000, nrTimeEntriesInDb);

      //int nrEmployeesInDb = db.Employees.Count();
      //Assert.Equal(30, nrEmployeesInDb);
    }
  }
}
