﻿namespace WebFramework;

public class ServerThread
{
  private readonly TcpClient _connection;

  public static Assembly? ExecutingAssembly { get; set; }
  public static string Namespace { get; set; } = "";

  public ServerThread(TcpClient connection) => _connection = connection;

  public void Start() => new Thread(Run).Start();

  #region --------------------------------------------------------- framework
  public void Run()
  {
    Console.WriteLine();
    Console.WriteLine("____________________________________________ Client connected");
    var outStream = _connection.GetStream();
    var inStream = new StreamReader(_connection.GetStream());
    HandleRequest(inStream, outStream);
    _connection.Close();
    Console.WriteLine("____________________________________________ Client disconnected");
  }

  private static void HandleRequest(StreamReader inStream, Stream outStream)
  {
    try
    {
      string? request = ReadRequest(inStream);                            //1 - ReadRequest
      string mime = "text/html";                                          //2 - detect MIME
      string responseContent = PrepareResponse(request);                  //3 - PrepareResponse
      outStream.WriteResponse(responseContent, mime, StatusCode.HTTP_OK); //4 - WriteResponse
    }
    catch (Exception exc)
    {
      outStream.WriteErrorResponse(StatusCode.HTTP_INTERNAL_SERVER_ERROR, exc.Message);
    }
  }

  private static string ReadRequest(StreamReader inStream)
  {
    var linesIn = inStream.ReadAllLinesFromStream();
    linesIn.ForEach(x => x.PrintWithColor("-->", ConsoleColor.Green, ConsoleColor.Black, ExtensionMethods.INOUT_PAD));
    if (!linesIn.Any()) throw new Exception("No route data in request");
    string? request = linesIn.First();
    return request;
  }

  public static string PrepareResponse(string request)
  {
    return "Server is working";
  }
  #endregion

}
