﻿namespace PersonsDb;
public class Class1
{

}
