namespace PersonsBackendSqlite.Dtos; 
public class YourDtosComeHere {} 
