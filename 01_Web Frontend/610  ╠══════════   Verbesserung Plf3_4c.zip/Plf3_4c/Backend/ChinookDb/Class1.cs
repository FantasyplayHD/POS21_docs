﻿namespace ChinookDb;
public class Class1
{

}
