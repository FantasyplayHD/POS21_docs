namespace ChinookBackend.Controllers;

[Route("[controller]")]
[ApiController]
public class ValuesController : ControllerBase
{
  private readonly ChinookContext _db;
  public ValuesController(ChinookContext db) => _db = db;

  [HttpGet("Artists")]
  public object GetArtists()
  {
    Console.WriteLine($"{DateTime.Now:HH:mm:ss} GetArtists");
    try
    {
  	  int nr = _db.Artists.Count();
  	  return new { IsOk = true, Nr = nr };
    }
    catch (Exception exc)
    {
  	  return new { IsOk = false, Nr = -1, Error = exc.Message };
    }
  }

}
