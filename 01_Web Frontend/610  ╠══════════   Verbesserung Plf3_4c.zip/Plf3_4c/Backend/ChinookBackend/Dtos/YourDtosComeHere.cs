﻿namespace ChinookBackend.Dtos;

public class YourDtosComeHere
{
}
