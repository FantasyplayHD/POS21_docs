$(_ => {
  console.log('window loaded');
  $('#lblMsg').addClass('ok').removeClass('nok').html('Ok');

  // const baseUrl = 'http://localhost:5000/chinook';

});

