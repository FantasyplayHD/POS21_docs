export interface NewOrderDetailDto {
  orderId: number;
  productId: number;
  quantity: number;
}
