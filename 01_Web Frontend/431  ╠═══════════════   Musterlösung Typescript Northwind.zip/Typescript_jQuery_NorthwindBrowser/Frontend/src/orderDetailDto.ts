export interface OrderDetailDto {
  quantity: number;
  productId: number;
  productName: string;
  categoryName: string;
  unitPrice: number;
}
