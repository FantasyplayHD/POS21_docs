export interface CustomerDto {
  id: string;
  name: string;
}
