export interface ProductDto {
  productId: number;
  productName: string;
}