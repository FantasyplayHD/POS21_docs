export interface OrderDto {
  orderId: number;
  employeeName: string;
  freight: number;
  shipName: string;
  shippedDateString: string;
  orderDateString: string;
}
