import { OrderDto, CustomerDto, OrderDetailDto, ProductDto, NewOrderDetailDto } from './models';
import $ from 'jquery';

$(_ => {
  const baseUrl = 'http://localhost:5000';

  const loading = $('#loading');
  const divInitials = $('#initials');
  const tblOrders = $('#tblOrders');
  const lblCustomerId = $('#lblCustomerId');
  const tblOrderDetails = $('#tblOrderDetails');
  const lblOrderId = $('#lblOrderId');
  const cboNewOrderProduct = $('#cboNewOrderProduct');
  const divAddOrderDetail = $('#divAddOrderDetail');

  $('#btnSaveNewOrderDetail').on('click', saveNewOrderDetail);

  let currentOrderId = 0;

  $.ajaxSetup({
    beforeSend: function(_) { loading.show(); },
    complete: _ => loading.hide()
  });

  $.getJSON(`${baseUrl}/customers/initials`)
    .then((data: string[]) => {
      let isFirst = true;
      data.forEach(x => {
        const p = $('<p>')
          .addClass('initial')
          .html(x)
          .on('click', loadCustomers)
          .appendTo(divInitials);
        if (isFirst) {
          isFirst = false;
          p.trigger('click');
        }
      });
    });

  $.getJSON(`${baseUrl}/products`)
    .then((data: ProductDto[]) => data.forEach(x =>
      $('<option>')
        .val(`${x.productId}`)
        .html(x.productName)
        .appendTo(cboNewOrderProduct))
    );
  divAddOrderDetail.hide();

  function loadCustomers(ev: JQuery.ClickEvent): void {
    const $initial = $(ev.target);
    const initial = $initial.text();
    console.log(`loadCustomers ${initial}`);
    $initial.siblings().children().remove();

    $.getJSON(`${baseUrl}/customers/${initial}`)
      .then((data: CustomerDto[]) => {
        console.table(data);
        const ul = $('<ul>')
          .addClass('customer')
          .appendTo($initial);
        let firstLi: JQuery<HTMLElement> | null = null;
        let isFirst = true;
        for (const { id, name } of data) {
          const li = $('<li>')
            .html(name)
            .attr('data-id', id)
            .on('click', loadOrders)
            .on('mouseenter', ev => $(ev.target).addClass('highlight'))
            .on('mouseleave', ev => $(ev.target).removeClass('highlight'))
            .appendTo(ul);
          if (isFirst) {
            isFirst = false;
            firstLi = li;
          }
        }
        if (firstLi) firstLi.trigger('click');
      });
  }

  function loadOrders(ev: JQuery.ClickEvent): boolean {
    tblOrders.empty();
    const customerId = $(ev.target).attr('data-id');
    console.log(`loadOrders ${customerId}`);

    $.getJSON(`${baseUrl}/orders?customerId=${customerId}`)
      .then((data: OrderDto[]) => {
        lblCustomerId.html(customerId ?? 'Unknown');
        let isFirst = true;
        data.forEach(x => {
          const tr = $('<tr>')
            .attr('data-id', x.orderId)
            .on('click', _ => loadOrderDetails(x.orderId))
            .on('mouseenter', ev => $(ev.target).closest('tr').addClass('highlight'))
            .on('mouseleave', ev => $(ev.target).closest('tr').removeClass('highlight'))
            .append($('<td>').html(x.orderDateString))
            .append($('<td>').html(x.employeeName))
            .append($('<td>').html(x.shippedDateString))
            .append($('<td>').html(`${x.freight}`).addClass('rightAlign'))
            .append($('<td>').html(x.shipName))
            .appendTo(tblOrders);
          if (isFirst) {
            isFirst = false;
            tr.trigger('click');
          }
        });

      });

    return false; //prevent event bubbling
    //event.stopPropagation();
  }

  function loadOrderDetails(orderId: number): void {
    tblOrderDetails.empty();
    $.getJSON(`${baseUrl}/orderdetails?orderId=${orderId}`)
      .then((data: OrderDetailDto[]) => {
        console.table(data);
        lblOrderId.html(`${orderId}`);
        data.forEach(x => {
          $('<tr>')
            .append($('<td>').html(`${x.quantity}`).addClass('rightAlign'))
            .append($('<td>').html(x.productName))
            .append($('<td>').html(x.categoryName))
            .append($('<td>').html(`${x.unitPrice.toFixed(2)} €`).addClass('rightAlign'))
            .append($('<td>').append(createDeleteButton(orderId, x.productId)))
            .appendTo(tblOrderDetails);
        });
        const total = data.reduce((p, c) => p + c.unitPrice * c.quantity, 0);
        $('<tr>')
          .appendTo(tblOrderDetails)
          .append($('<td>')
            .attr('colspan', 3)
            .addClass('rightAlign')
            .html('Total'))
          .append($('<td>').addClass('rightAlign').html(`${total.toFixed(2)} €`))
          .append($('<td>').append(createAddButton(orderId)));
      });
  }

  function createDeleteButton(orderId: number, productId: number): JQuery<HTMLElement> {
    const button = $('<button>')
      .addClass('btn')
      .addClass('btn-danger')
      .on('click', _ => deleteOrderDetail(orderId, productId));
    $('<i>').addClass('bi-trash').appendTo(button);
    return button;
  }

  function deleteOrderDetail(orderId: number, productId: number): void {
    console.log(`delete OrderDetail ${orderId}/${productId}`);
    $.ajax({
      url: `${baseUrl}/orderdetails?orderId=${orderId}&productId=${productId}`,
      method: 'DELETE'
    })
      .then(_ => loadOrderDetails(orderId));
  }

  function createAddButton(orderId: number): JQuery<HTMLElement> {
    const button = $('<button>')
      .addClass('btn')
      .addClass('btn-success')
      .on('click', _ => addOrderDetail(orderId));
    $('<i>').addClass('bi-bag-plus-fill').appendTo(button);
    return button;
  }

  function addOrderDetail(orderId: number): void {
    console.log(`add OrderDetail ${orderId}`);
    divAddOrderDetail.show();
    currentOrderId = orderId;
  }

  function saveNewOrderDetail(): void {
    console.log(`save OrderDetail ${currentOrderId}`);
    const data: NewOrderDetailDto = {
      orderId: currentOrderId,
      productId: +(cboNewOrderProduct.find('option:selected').val() ?? 0),
      quantity: +($('#txtNewOrderDetailAmount').val() ?? 0)
    };
    $.ajax({
      url: `${baseUrl}/orderdetails`,
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(data)
    })
      .then(_ => {
        divAddOrderDetail.hide();
        loadOrderDetails(currentOrderId);
      });
  }

});