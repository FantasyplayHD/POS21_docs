﻿namespace NorthwindDb;
public class Class1
{

}
