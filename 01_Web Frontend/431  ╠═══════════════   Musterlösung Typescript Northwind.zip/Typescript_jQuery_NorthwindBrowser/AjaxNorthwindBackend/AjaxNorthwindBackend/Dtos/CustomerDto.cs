﻿namespace AjaxNorthwindBackend.Dtos;

public class CustomerDto
{
  public string Id { get; set; } = null!;
  public string Name { get; set; } = null!;
}
