﻿namespace AjaxNorthwindBackend.Dtos;

public class OrderDto
{
  public int OrderId { get; set; }
  [JsonIgnore] public DateTime? OrderDate { get; set; }
  public string EmployeeName { get; set; } = null!;
  [JsonIgnore] public DateTime? ShippedDate { get; set; }
  public double Freight { get; set; }
  public string ShipName { get; set; } = null!;
  public string ShippedDateString => ShippedDate.HasValue ? $"{ShippedDate:yyyy-MM-dd}" : "-";
  public string OrderDateString => OrderDate.HasValue ? $"{OrderDate:yyyy-MM-dd}" : "-";
}

