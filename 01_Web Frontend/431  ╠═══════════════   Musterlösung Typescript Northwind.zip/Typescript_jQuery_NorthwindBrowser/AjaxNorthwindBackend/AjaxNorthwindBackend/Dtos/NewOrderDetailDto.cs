﻿namespace AjaxNorthwindBackend.Dtos;

public class NewOrderDetailDto
{
  public int OrderId { get; set; }
  public int ProductId { get; set; }
  public short Quantity { get; set; }

  public override string ToString() => $"{Quantity}x{ProductId} for OrderId {OrderId}";
}
