﻿namespace AjaxNorthwindBackend.Dtos;

public class OrderDetailDto
{
  public double Quantity { get; set; }
  public int ProductId { get; set; }
  public string ProductName { get; set; } = null!;
  public string CategoryName { get; set; } = null!;
  public decimal UnitPrice { get; set; }
}
