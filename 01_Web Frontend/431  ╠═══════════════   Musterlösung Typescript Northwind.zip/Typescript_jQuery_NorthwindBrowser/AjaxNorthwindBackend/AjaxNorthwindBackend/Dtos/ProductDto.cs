﻿namespace AjaxNorthwindBackend.Dtos;

public class ProductDto
{
  public int ProductId { get; set; }
  public string ProductName { get; set; } = null!;
}
