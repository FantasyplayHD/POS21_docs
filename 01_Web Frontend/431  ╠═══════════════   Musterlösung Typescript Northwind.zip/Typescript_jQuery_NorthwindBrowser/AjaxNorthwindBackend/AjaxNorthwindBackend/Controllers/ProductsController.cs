﻿namespace AjaxNorthwindBackend.Controllers;

[Route("[controller]")]
[ApiController]
public class ProductsController : ControllerBase
{
  private readonly NorthwindContext _db;
  public ProductsController(NorthwindContext db) => _db = db;

  [HttpGet]
  public List<ProductDto> GetProducts()
  {
    Console.WriteLine("GetProducts");
    return _db.Products
      .OrderBy(x => x.ProductName)
      .Select(x => new ProductDto().CopyPropertiesFrom(x))
      .ToList();
  }
}
