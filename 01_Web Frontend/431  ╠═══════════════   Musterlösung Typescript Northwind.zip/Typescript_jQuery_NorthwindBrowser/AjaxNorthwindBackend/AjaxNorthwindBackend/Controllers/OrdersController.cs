﻿namespace AjaxNorthwindBackend.Controllers;

[Route("[controller]")]
[ApiController]
public class OrdersController : ControllerBase
{
  private readonly NorthwindContext _db;
  public OrdersController(NorthwindContext db) => _db = db;

  [HttpGet]
  public List<OrderDto> GetOrdersOfCustomer(string customerId)
  {
    Console.WriteLine($"GetOrdersOfCustomer {customerId}");
    return _db.Orders
      .Include(y => y.Employee)
      .Include(y => y.Customer)
      .Where(x => x.Customer!.CustomerId == customerId)
      .OrderBy(x => x.OrderDate)
      .Select(item => new OrderDto
      {
        OrderId = item.OrderId,
        EmployeeName = $"{item.Employee!.LastName} {item.Employee.FirstName}",
        OrderDate = item.OrderDate,
        Freight = (double)(item.Freight ?? 0),
        ShipName = item.ShipName ?? "-",
        ShippedDate = item.ShippedDate
      })
      .ToList();
  }
}
