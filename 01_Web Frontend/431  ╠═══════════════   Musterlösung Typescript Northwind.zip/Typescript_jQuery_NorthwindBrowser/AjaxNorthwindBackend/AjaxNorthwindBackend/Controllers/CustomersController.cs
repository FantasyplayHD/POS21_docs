﻿namespace AjaxNorthwindBackend.Controllers;

[Route("[controller]")]
[ApiController]
public class CustomersController : ControllerBase
{
  private readonly NorthwindContext _db;
  public CustomersController(NorthwindContext db) => _db = db;

  [HttpGet("initials")]
  public List<string> Initials()
  {
    Console.WriteLine("Initials");
    return _db.Customers
       .ToList()
       .Select(x => x.CompanyName[..1].ToUpper())
       .Distinct()
       .OrderBy(x => x)
       .ToList();
  }

  [HttpGet("{initial}")]
  public List<CustomerDto> GetCustomersWithInitials(string initial)
  {
    Console.WriteLine($"GetCustomersWithInitials {initial}");
    return _db.Customers
      .Where(x => x.CompanyName.ToUpper().StartsWith(initial))
      .Select(x => new CustomerDto
      {
        Id = x.CustomerId,
        Name = x.CompanyName
      })
      .ToList();
  }
}
