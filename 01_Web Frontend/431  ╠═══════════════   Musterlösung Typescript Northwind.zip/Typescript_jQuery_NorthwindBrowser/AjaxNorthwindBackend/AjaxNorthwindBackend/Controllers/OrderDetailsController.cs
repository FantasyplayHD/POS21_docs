﻿namespace AjaxNorthwindBackend.Controllers;

[Route("[controller]")]
[ApiController]
public class OrderDetailsController : ControllerBase
{
  private readonly NorthwindContext _db;
  public OrderDetailsController(NorthwindContext db) => _db = db;


  [HttpGet]
  public List<OrderDetailDto> GetOrderDetails(int orderId)
  {
    Console.WriteLine($"GetOrderDetails or OrderId {orderId}");
    return _db.OrderDetails
      .Include(y => y.Product)
      .ThenInclude(y => y.Category)
      .Where(x => x.Order.OrderId == orderId)
      .OrderBy(x => x.Product.ProductName)
      .Select(x => new OrderDetailDto
      {
        CategoryName = x.Product!.Category!.CategoryName,
        UnitPrice = x.UnitPrice,
        ProductId = x.ProductId,
        ProductName = x.Product.ProductName,
        Quantity = x.Quantity
      })
      .ToList();
  }

  [HttpDelete]
  public OrderDetailDto DeleteOrderDetail(int orderId, int productId)
  {
    Console.WriteLine($"DeleteOrderDetail: orderId {orderId} / productId {productId}");
    var toDelete = _db.OrderDetails.Where(x => x.OrderId == orderId && x.ProductId == productId).ToList();
    if (!toDelete.Any())
    {
      Console.WriteLine("No OrderDetails found!");
      return new OrderDetailDto();
    }
    var dto = new OrderDetailDto().CopyPropertiesFrom(toDelete.First());
    _db.OrderDetails.RemoveRange(toDelete);
    _db.SaveChanges();
    return dto;
  }

  [HttpPost]
  public string AddOrderDetail([FromBody] NewOrderDetailDto dto)
  {
    Console.WriteLine($"AddOrderDetail: {dto}");
    decimal unitPrice = _db.Products.Single(x => x.ProductId == dto.ProductId).UnitPrice ?? 0;
    var orderDetail = new OrderDetail().CopyPropertiesFrom(dto);
    orderDetail.UnitPrice = unitPrice;
    _db.OrderDetails.Add(orderDetail);
    _db.SaveChanges();
    return "Done";
  }
}
