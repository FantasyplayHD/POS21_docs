import { Product } from "./product";

export const products: Product[] =
  [
    {
      id: 1,
      name: 'Apfel',
      category: 'Obst',
      price: 0.49
    },
    {
      id: 2,
      name: 'Birne',
      category: 'Obst',
      price: 0.59
    },
    {
      id: 3,
      name: 'Banane',
      category: 'Obst',
      price: 0.39
    },
    {
      id: 4,
      name: 'Melone',
      category: 'Obst',
      price: 1.49
    },
    {
      id: 5,
      name: 'Semmel',
      category: 'Backwaren',
      price: 0.32
    },
    {
      id: 6,
      name: 'Brot',
      category: 'Backwaren',
      price: 3.99
    },
    {
      id: 7,
      name: 'Kornspitz',
      category: 'Backwaren',
      price: 0.89
    },
    {
      id: 8,
      name: 'Kipferl',
      category: 'Backwaren',
      price: 1.29
    }
  ];