import { Component, OnInit } from '@angular/core';

import { Product } from './product';
import { Order } from './order';
import { products } from './products';

const orders: Order[] = [];

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  products: Product[] = products;
  orders: Order[] = orders;
  productAmount = 3;
  currentProduct = products[0];
  sum = 10;
  discount = 0;
  total = 0;

  ngOnInit(): void {
    this.orders.push({ product: this.products[3], quantity: 12 });
    this.orders.push({ product: this.products[1], quantity: 5 });
    this.orders.push({ product: this.products[6], quantity: 6 });
    this.calcTotal();
  }

  getPrice(product: Product, quantity: number): number {
    const price = product.price * quantity;
    console.log(`getPrice: ${product.price}*${quantity}=${price}`);
    return price;
  }

  addOrder(product: Product, amount: number): void {
    console.log(`Add ${amount} x ProductId ${product.name}`);
    const order: Order = {
      product,
      quantity: amount
    };
    this.orders.push(order);
    this.calcTotal();
  }

  deleteOrder(index: number): void {
    console.log(`deleteOrder ${index}`);
    this.orders.splice(index, 1);
    this.calcTotal();
  }

  calcTotal(): void {
    // this.sum = 0;
    // for (const price of this.orders.map(x => x.product.price * x.quantity)) {
    //   this.sum += price;
    // }
    this.sum = this.orders
      .map(x => x.product.price * x.quantity)
      .reduce((x, y) => x + y, 0);
    this.discount = (this.sum >= 100) ? 10 : 0;
    this.total = this.sum - this.discount;
  }
}

