﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ProjectManager
{
  public partial class MainWindow : Window
  {
    public MainWindow() => InitializeComponent();

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      var cultureInfo = new System.Globalization.CultureInfo("en-US");
      cultureInfo.NumberFormat.NumberDecimalSeparator = ".";
      System.Threading.Thread.CurrentThread.CurrentUICulture = cultureInfo;

    }

  }
}
