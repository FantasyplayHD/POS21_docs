﻿namespace WpfDemoEf6;

public partial class App : Application
{
}
