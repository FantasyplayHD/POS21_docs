﻿using Microsoft.Extensions.Configuration;

namespace WpfDemoEf6;

public partial class MainWindowNet6Demo : Window
{
  public MainWindowNet6Demo() => InitializeComponent();

  private void Window_Loaded(object sender, RoutedEventArgs e)
  {
    var config = new ConfigurationBuilder()
      .SetBasePath(AppContext.BaseDirectory)
      .AddJsonFile("appsettings.json")
      .Build();
    string connectionString = config.GetConnectionString("NorthwindDb_Mdf");
    var options = new DbContextOptionsBuilder<NorthwindContext>()
      .LogTo(x =>
      {
        Console.WriteLine(x);
        lstLogs.Items.Add(x);
      }, Microsoft.Extensions.Logging.LogLevel.Information)
      .UseSqlServer(connectionString)
      .Options;

    try
    {
      var db = new NorthwindContext(options);
      int nr = db.Categories.Count();
      Title = $"nr = {nr}";
      var sql = db.Products;
      string s = sql.ToQueryString();
      var products = sql.ToList();
      lstProducts.ItemsSource = products;
      AddCategory(db);
      UpdateCategory(db);
    }
    catch (Exception ex)
    {
      Title = ex.Message;
    }
  }

  private void UpdateCategory(NorthwindContext db)
  {
    //var category = new Category { CategoryId = 8, CategoryName = "Quaxi", Description = "Description for Quaxi" };
    var category = db.Categories.First(x => x.CategoryName == "Quaxi");
    Log($"--read: {db.Entry(category).State}");
    category.Description = "Other Description";
    Log($"--updated: {db.Entry(category).State}");
    db.SaveChanges();
    Log($"--saved: {db.Entry(category).State}");
    Title = $"nr = {db.Categories.Count()}";
  }

  private void AddCategory(NorthwindContext db)
  {
    var category = new Category { CategoryName = "Quaxi", Description = "Description for Quaxi" };
    Log($"--created: {db.Entry(category).State}");
    db.Categories.Add(category);
    Log($"--added: {db.Entry(category).State}");
    db.SaveChanges();
    Log($"--saved: {db.Entry(category).State}");
    Title = $"nr = {db.Categories.Count()}";
  }

  private void Log(string v)
  {
    Console.WriteLine(v);
    lstLogs.Items.Add(v);
  }
}
