﻿global using Microsoft.EntityFrameworkCore;
global using NorthwindDbLib;
global using System;
global using System.Linq;
global using System.Windows;
global using System.Windows.Controls;