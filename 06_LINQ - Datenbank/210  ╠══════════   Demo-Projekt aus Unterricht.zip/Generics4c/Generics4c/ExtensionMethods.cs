﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics4c
{
  public static class ExtensionMethods
  {
    public static T Middle<T>(this List<T> values)
    {
      int index = values.Count / 2;
      T val = values[index];
      return val;
    }
    public static S Middle<T,S>(this List<T> values, Func<T, S> transformer)
    {
      int index = values.Count / 2;
      T val = values[index];
      return transformer(val);
    }

    public static int Squared(this int val)
    {
      return val * val;
    }
  }
}
