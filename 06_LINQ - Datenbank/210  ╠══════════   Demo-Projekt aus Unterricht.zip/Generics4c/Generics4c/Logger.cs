﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics4c
{
  //Action<T>
  //Action<T1,T2>
  //Action<T1,T2,T3>
  //Action<T1,T2,T3,...,T16>
  //Action<string>
  public delegate void LogFunction(string msg);
  //Func<string,int>
  public delegate int StringToIntFunction(string s);
  //Func<List<double>,double,double>
  public delegate double AverageFromDoubleList(List<double> s, double maxValue);
  //Func<List<string>,float,int>
  public delegate int AverageFromStringList(List<string> s, float maxValue);

  //return void     ==> Action
  //return non-void ==> Func
  //return bool     ==> Predicate --> Func<...,bool>


  public class Logger
  {
    private Action<string> logFunction;
    //private LogFunction logFunction;
    public Logger(Action<string> myLogFunction)
    {
      logFunction = myLogFunction;
    }
    public void LogSimple(string msg)
    {
      Console.WriteLine(msg);
    }
    public void LogWithClock(string msg)
    {
      Console.WriteLine($"{DateTime.Now:HH:mm:ss.fff} {msg}");
    }
    public void Log(string msg)
    {
      logFunction(msg);
    }
  }
}
