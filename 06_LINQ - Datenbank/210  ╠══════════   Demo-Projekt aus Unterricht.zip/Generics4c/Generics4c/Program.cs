﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Generics4c
{
  class Program
  {
    static void Main(string[] args)
    {
      var integers = new List<int> { 4, 67, 2, 9, 87, 36, 26, 3 };
      var doubles = new List<double> { 6.3, 54.8, 134.9, 8.43, 76.2 };
      var strings = new List<string> { "a", "b", "c", "d", "e", "f" };
      int middleInt = integers.Middle();
      Console.WriteLine($"middleInt = {middleInt}");
      double middleDouble = doubles.Middle();
      Console.WriteLine($"middleDouble = {middleDouble}");
      string middleString = strings.Middle();
      Console.WriteLine($"middleString = {middleString}");

      string mm = doubles.Middle(x => $"{x:0.000}");
      Console.WriteLine($"mm = {mm}");

      int x = 3;
      int squared = x.Squared();
      integers.Select(x => $"{x}");//Func<int,string>
      Console.WriteLine($"{x}*{x} = {squared}");

      TestLogger();
      Console.ReadKey();
    }

    #region old stuff
    //private static int Middle(List<int> values)
    //{
    //  int index = values.Count / 2;
    //  int val = values[index];
    //  return val;
    //}
    //private static double Middle(List<double> values)
    //{
    //  int index = values.Count / 2;
    //  double val = values[index];
    //  return val;
    //}
    //private static string Middle(List<string> values)
    //{
    //  int index = values.Count / 2;
    //  string val = values[index];
    //  return val;
    //}
    #endregion

    private static void TestLogger()
    {
      var logger = new Logger(x => Console.WriteLine($"dsflkjaldkfj: {x}"));
      logger.LogSimple("abc");
      logger.LogWithClock("def");
      logger.Log("ghi");
    }

    //public static void MyLog(string msg)
    //{
    //  Console.WriteLine($"Main: {msg}");
    //}
  }
}
