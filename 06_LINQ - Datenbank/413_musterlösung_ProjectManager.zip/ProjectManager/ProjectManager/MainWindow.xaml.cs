﻿using Microsoft.EntityFrameworkCore;
using ProjectDbLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ProjectManager
{
  public partial class MainWindow : Window
  {
    private ProjectContext db;
    private List<string> departments = new();
    private List<Project> projects = new();

    public MainWindow() => InitializeComponent();

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      var cultureInfo = new System.Globalization.CultureInfo("en-US");
      cultureInfo.NumberFormat.NumberDecimalSeparator = ".";
      System.Threading.Thread.CurrentThread.CurrentUICulture = cultureInfo;

      InitDb();
      TestDb();

      departments = db.Employees.Select(x => x.Department)
                      .Distinct().OrderBy(x => x)
                      .ToList();
      projects = db.Projects.ToList();

      RefreshList();

      AddDepartmentRadios();
      AddProjectCheckboxes();

      panDepartments.Children.OfType<RadioButton>().Single(x => x.Content.ToString() == "Sales").IsChecked = true;

      txtDepartment_KeyUp(null, null);
      txtProjects_KeyUp(null, null);
    }

    #region ------------------------------------------------------------- Database
    private void InitDb()
    {
      db = new ProjectContext();
      int nrProjects = db.Projects.Count();
      if (nrProjects == 3) ReadCsvs();
    }

    private void TestDb()
    {
      int nrProjects = db.Projects.Count();
      Console.WriteLine($"nrProjects = {nrProjects}");
      int nrEmployees = db.Employees.Count();
      Console.WriteLine($"nrEmployees = {nrEmployees}");
      int nrProjectEmployees = db.ProjectEmployees.Count();
      Console.WriteLine($"nrProjectEmployees = {nrProjectEmployees}");
    }
    #endregion

    #region ---------------------------------------------- Add controls
    private void AddProjectCheckboxes()
    {
      Console.WriteLine("AddProjectCheckboxes");
      foreach (var project in projects)
      {
        var checkbox = new CheckBox { Content = project.Name, IsChecked = true };
        checkbox.Checked += Project_Checked;
        checkbox.Unchecked += Project_Unchecked;
        panProjects.Children.Add(checkbox);
      }
    }

    private void AddDepartmentRadios()
    {
      Console.WriteLine("AddDepartmentRadios");
      foreach (var department in departments)
      {
        var radio = new RadioButton { Content = department };
        radio.Checked += Department_Checked;
        panDepartments.Children.Add(radio);
      }
    }
    #endregion

    #region ---------------------------------------------- Checked/Unchecked
    private void Department_Checked(object sender, RoutedEventArgs e)
    {
      Console.WriteLine($"Department_Checked {(sender as RadioButton).Content}");
      RefreshList();
    }

    private void Project_Checked(object sender, RoutedEventArgs e)
    {
      Console.WriteLine($"Project_Checked {(sender as CheckBox).Content}");
      RefreshList();
    }

    private void Project_Unchecked(object sender, RoutedEventArgs e)
    {
      Console.WriteLine($"Project_Unchecked {(sender as CheckBox).Content}");
      RefreshList();
    }
    #endregion

    #region ---------------------------------------------- Csv
    private void ReadCsvs()
    {
      Console.WriteLine("ReadCsvs");
      ReadProjectCsv();
      ReadEmployeeCsv();
      ReadProjectEmployees();
    }

    private void ReadProjectEmployees()
    {
      //Note: the Employess and Projects must have been saved to the database already!
      Console.WriteLine("ReadProjectEmployees");
      //Employee;Project
      //James Cello;ProjectD
      File.ReadAllLines(@"csv\project_employees.csv")
        .Skip(1)
        .Select(x => x.Split(";"))
        .Select(x => new ProjectEmployee
        {
          AssingDate = DateTime.Now,
          Employee = db.Employees.Single(y => y.Lastname + " " + y.Firstname == x[0]), //don't use $"..."--> cannot be translated to SQL
          Project = db.Projects.Single(y => y.Name == x[1])
        })
        .ToList()
        .ForEach(x => db.ProjectEmployees.Add(x));
      db.SaveChanges();
      Console.WriteLine($"  {db.ProjectEmployees.Count()} project_employees added");
    }

    private void ReadProjectCsv()
    {
      Console.WriteLine("ReadProjectCsv");
      //4;ProjectD
      File.ReadAllLines(@"csv\projects.csv")
        .Select(x => x.Split(';'))
        .Select(x => new Project { Name = x[1] })
        .ToList()
        .ForEach(x => db.Projects.Add(x));
      db.SaveChanges();
      Console.WriteLine($"  {db.Projects.Count()} projects added");
    }

    private void ReadEmployeeCsv()
    {
      Console.WriteLine("ReadEmployeeCsv");
      //id;firstname;lastname;age;salary;department
      //51;Cory;McCallion;42;3392.1;Sales
      File.ReadAllLines(@"csv\employees.csv")
        .Skip(1)
        .Select(x => Employee.Parse(x))
        .ToList()
        .ForEach(x => db.Employees.Add(x));
      db.SaveChanges();
      Console.WriteLine($"  {db.Employees.Count()} employees added");
    }
    #endregion

    #region ---------------------------------------------- RefreshList
    private void RefreshList()
    {
      Console.WriteLine("RefreshList");
      var employees = db.Employees
        .Include(x => x.ProjectEmployees)
        .ThenInclude(x => x.Project)
        .ToList();
      lstEmployees.Items.Clear();
      var checkedDepartments = panDepartments.Children.OfType<RadioButton>()
        .Where(x => x.IsChecked ?? false)
        .Select(x => x.Content.ToString());
      var checkedProjects = panProjects.Children.OfType<CheckBox>()
        .Where(x => x.IsChecked ?? false)
        .Select(x => x.Content.ToString());
      foreach (var employee in employees)
      {
        if (!checkedDepartments.Contains(employee.Department)) continue;
        bool hasCheckedProject = false;
        var projects = db.ProjectEmployees
          .Where(x => x.Employee.Id == employee.Id)
          .Select(x => x.Project)
          .ToList();
        foreach (var project in projects)
        {
          if (checkedProjects.Contains(project.Name)) hasCheckedProject = true;
        }
        if (!hasCheckedProject) continue;
        lstEmployees.Items.Add(employee);
      }
      grdEmployees.ItemsSource = db.ProjectEmployees
        .Where(x => checkedDepartments.Contains(x.Employee.Department))
        .Where(x => checkedProjects.Contains(x.Project.Name))
        .Select(x => new EmployeeRow
        {
          Name = $"{x.Employee.Lastname} {x.Employee.Firstname}",
          Department = x.Employee.Department,
          DateString = $"{x.AssingDate:yyyy-MM-dd}",
          Project = x.Project.Name,
        })
        .ToList();
    }
    #endregion

    #region ---------------------------------------------- BtnAdd_Click + InputCheck
    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
      Console.WriteLine("BtnAdd_Click");
      var employee = new Employee
      {
        Id = db.Employees.Max(x => x.Id) + 1,
        Firstname = txtFirstname.Text,
        Lastname = txtLastname.Text,
        Age = int.Parse(txtAge.Text),
        Salary = double.Parse(txtSalary.Text),
        Department = txtDepartment.Text
      };
      db.Employees.Add(employee);

      txtProjects.Text
         .Split(',')
         .Select(x => x.Trim())
         .Select(x => projects.Single(y => y.Name == x))
         .Select(x => new ProjectEmployee
         {
           Employee = employee,
           Project = x,
           AssingDate = DateTime.Now
         })
         .ToList()
         .ForEach(x => db.ProjectEmployees.Add(x));
      db.SaveChanges();
      RefreshList();
    }

    private void txtDepartment_KeyUp(object sender, KeyEventArgs e) => CheckInputs();
    private void txtProjects_KeyUp(object sender, KeyEventArgs e) => CheckInputs();

    private void CheckInputs()
    {
      bool isDepartmentOk = CheckDepartment();
      bool isProjectOk = CheckProject();
      btnAdd.IsEnabled = isDepartmentOk && isProjectOk;
    }

    private bool CheckDepartment()
    {
      bool isOk = departments.Contains(txtDepartment.Text.Trim());
      txtDepartment.Background = isOk ? Brushes.White : Brushes.Red;
      return isOk;
    }

    private bool CheckProject()
    {
      string value = txtProjects.Text;
      Console.WriteLine($"CheckProject for {value}");
      if (value.Trim().Length == 0) return false; //"no project" is allowed
      var projectsEntered = value.Split(',').Select(x => x.Trim());
      var projectNamesAvailable = projects.Select(x => x.Name);
      bool isOk = true;
      foreach (var project in projectsEntered)
      {
        if (!projectNamesAvailable.Contains(project)) isOk = false;
      }
      txtProjects.Background = isOk ? Brushes.White : Brushes.Red;
      return isOk;
    }
    #endregion

  }
}
