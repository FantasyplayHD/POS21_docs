﻿namespace ProjectManager
{
  public class EmployeeRow
  {
    public string Name { get; set; }
    public string Department { get; set; }
    public string Project { get; set; }
    public string DateString { get; set; }
  }
}
