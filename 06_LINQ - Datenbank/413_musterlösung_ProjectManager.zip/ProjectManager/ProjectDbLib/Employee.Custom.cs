﻿using System.Linq;

namespace ProjectDbLib
{
  public partial class Employee
  {
    public string ProjectsString => string.Join(",", ProjectEmployees?.Select(x => x.Project?.Name).ToList() ?? new());
    public override string ToString() => $"{Lastname} {Firstname} ({Department}) [{ProjectsString}]";

    public static Employee Parse(string csvLine)
    {
      // 0     1         2     3    4       5
      //id;firstname;lastname;age;salary;department
      //51;Cory;McCallion;42;3392.1;Sales
      var items = csvLine.Split(";");
      return new Employee
      {
        Firstname = items[1],
        Lastname = items[2],
        Age = int.Parse(items[3]),
        Salary = double.Parse(items[4].Replace(".", ",")),
        Department = items[5],
      };
    }
  }
}
