﻿using System;

namespace NorthwindDbLib
{
  public class Class1
  {
  }
}
