﻿using System;

namespace Personlist
{
  public class Person
  {
    public string Firstname { get; set; }
    public string Lastname { get; set; }
    public bool IsMale { get; set; }
    public bool HasDriversLicence { get; set; }
    public DateTime Birthdate { get; set; }

    private string GenderString => IsMale ? "Male" : "Female";
    private string DriverString => HasDriversLicence ? ", Driver" : "";
    public override string ToString() => $"{Lastname} {Firstname} - {Birthdate:dd.MM.yyyy} [{GenderString}{DriverString}]";

    public string AsCsvString() => $"{Firstname};{Lastname};{IsMale};{HasDriversLicence};{Birthdate:dd.MM.yyyy}";

    public static Person Parse(string csvLine)
    {
      //  0  ;  1  ;  2 ;  3  ;  4
      //-------------------------------
      //Lukas;Turek;true;false;4.4.1968
      var items = csvLine.Split(';');
      return new Person
      {
        Firstname = items[0],
        Lastname = items[1],
        IsMale = bool.Parse(items[2]),
        HasDriversLicence = bool.Parse(items[3]),
        Birthdate = DateTime.Parse(items[4])
      };
    }

    public static bool TryParse(string csvLine, out Person person)
    {
      person = null;
      try
      {
        person = Parse(csvLine);
        return true;
      }
      catch (Exception exc)
      {
        Console.WriteLine(exc.Message);
        return false;
      }
    }

  }
}
