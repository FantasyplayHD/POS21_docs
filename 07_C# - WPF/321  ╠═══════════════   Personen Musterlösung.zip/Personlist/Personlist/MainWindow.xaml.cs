﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Personlist
{
  public partial class MainWindow : Window
  {
    public MainWindow() => InitializeComponent();

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtFirstname.Text = "Hansi";
      txtLastname.Text = "Huber";

      dtpBorn.DisplayDateEnd = DateTime.Now;
      dtpBorn.DisplayDateStart = new DateTime(1900, 1, 1, 0, 0, 0, 0);
      dtpBorn.SelectedDate = DateTime.Now.AddYears(-18);

      PopulateList(fewOnly: true);
      //SelectMultiplePersons();
      lstNames.SelectedItem = lstNames.Items[0];
    }

    private void MenuLoad_Click(object sender, RoutedEventArgs e)
    {
      string dir = Path.GetDirectoryName(this.GetType().Assembly.Location);
      var dlgOpen = new OpenFileDialog
      {
        DefaultExt = "csv",
        FileName = "persons.csv",
        Filter = "CSV files|*.csv|All files|*.*",
        //InitialDirectory = @"C:\Temp"
        InitialDirectory = dir
      };
      if (true != dlgOpen.ShowDialog()) return;

      lstNames.Items.Clear();
      string filename = dlgOpen.FileName;
      var lines = File.ReadAllLines(filename, Encoding.GetEncoding("ISO-8859-1"));
      foreach (string line in lines)
      {
        if (Person.TryParse(line, out var person)) lstNames.Items.Add(person);
      }
    }

    private void MenuSave_Click(object sender, RoutedEventArgs e)
    {
      var dlgSave = new SaveFileDialog
      {
        DefaultExt = "csv",
        FileName = "persons.csv",
        Filter = "CSV files|*.csv|All files|*.*",
        InitialDirectory = @"C:\Temp"
      };
      if (true != dlgSave.ShowDialog()) return;

      string filename = dlgSave.FileName;
      var writer = new StreamWriter(filename, false, Encoding.GetEncoding("ISO-8859-1"));
      foreach (Person person in lstNames.Items)
      {
        writer.WriteLine(person.AsCsvString());
      }
      writer.Close();
    }

    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
      if (dtpBorn.SelectedDate == null) return;
      lstNames.Items.Add(new Person
      {
        Lastname = txtLastname.Text,
        Firstname = txtFirstname.Text,
        Birthdate = dtpBorn.SelectedDate.Value,
        IsMale = rdoMale.IsChecked ?? true,
        HasDriversLicence = chkDriversLicence.IsChecked ?? true
      });
    }

    #region ----------------------------------------- PopulateList
    private void PopulateList(bool fewOnly)
    {
      if (fewOnly)
      {
        lstNames.Items.Add(new Person { Firstname = "Susi", Lastname = "Weber", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1991, 8, 7) });
        lstNames.Items.Add(new Person { Firstname = "Heinzi", Lastname = "Prüller", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1946, 4, 1) });
        lstNames.Items.Add(new Person { Firstname = "Fritzi", Lastname = "Mader", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1954, 2, 15) });
      }
      else
      {
        lstNames.Items.Add(new Person { Firstname = "Lukas", Lastname = "Turek", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1968, 4, 4) });
        lstNames.Items.Add(new Person { Firstname = "Lea", Lastname = "Schreiner", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1947, 5, 9) });
        lstNames.Items.Add(new Person { Firstname = "Oliver", Lastname = "Fuchs", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1966, 9, 12) });
        lstNames.Items.Add(new Person { Firstname = "Lisa", Lastname = "Funk", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1944, 4, 28) });
        lstNames.Items.Add(new Person { Firstname = "Gertrude", Lastname = "Zeilinger", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1985, 4, 5) });
        lstNames.Items.Add(new Person { Firstname = "Fritz", Lastname = "Ivanovic", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1975, 11, 11) });
        lstNames.Items.Add(new Person { Firstname = "Sebastian", Lastname = "Eder", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1976, 11, 27) });
        lstNames.Items.Add(new Person { Firstname = "Aynur", Lastname = "Yürük", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1977, 2, 27) });
        lstNames.Items.Add(new Person { Firstname = "Martin", Lastname = "Dielacher", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1964, 1, 3) });
        lstNames.Items.Add(new Person { Firstname = "Manuel", Lastname = "Habek", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1985, 3, 8) });
        lstNames.Items.Add(new Person { Firstname = "Klara", Lastname = "Heinz", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1985, 3, 2) });
        lstNames.Items.Add(new Person { Firstname = "Monika", Lastname = "Kettner", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1988, 4, 2) });
        lstNames.Items.Add(new Person { Firstname = "Sophie", Lastname = "Scharner", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1964, 5, 19) });
        lstNames.Items.Add(new Person { Firstname = "Stefan", Lastname = "Manhardt", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1970, 3, 16) });
        lstNames.Items.Add(new Person { Firstname = "Martina", Lastname = "Malcik", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1958, 5, 26) });
        lstNames.Items.Add(new Person { Firstname = "Matthias", Lastname = "Kreiner", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1960, 1, 13) });
        lstNames.Items.Add(new Person { Firstname = "Franz", Lastname = "Mautner", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1969, 12, 21) });
        lstNames.Items.Add(new Person { Firstname = "Andrea", Lastname = "Wendl", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1976, 7, 14) });
        lstNames.Items.Add(new Person { Firstname = "Karl", Lastname = "Walescek", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1941, 10, 26) });
        lstNames.Items.Add(new Person { Firstname = "Franz", Lastname = "Zoka", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1985, 8, 17) });
        lstNames.Items.Add(new Person { Firstname = "Heidi", Lastname = "Puchwein", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1968, 9, 14) });
        lstNames.Items.Add(new Person { Firstname = "Fritz", Lastname = "Frankmann", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1957, 7, 20) });
        lstNames.Items.Add(new Person { Firstname = "Karl", Lastname = "Kratz", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1963, 2, 12) });
        lstNames.Items.Add(new Person { Firstname = "Ökmen", Lastname = "Karadeniz", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1956, 1, 15) });
        lstNames.Items.Add(new Person { Firstname = "Dragana", Lastname = "Stanojevic", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1960, 12, 19) });
        lstNames.Items.Add(new Person { Firstname = "Andrea", Lastname = "Minnich", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1967, 4, 8) });
        lstNames.Items.Add(new Person { Firstname = "Josef", Lastname = "Mayer", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1942, 4, 28) });
        lstNames.Items.Add(new Person { Firstname = "Tanja", Lastname = "Huber", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1975, 3, 25) });
        lstNames.Items.Add(new Person { Firstname = "Sabine", Lastname = "Mittermaier", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1959, 3, 15) });
        lstNames.Items.Add(new Person { Firstname = "Michaela", Lastname = "Roiser", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1976, 1, 16) });
        lstNames.Items.Add(new Person { Firstname = "Franz", Lastname = "Sartor", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1944, 11, 16) });
        lstNames.Items.Add(new Person { Firstname = "Andrea", Lastname = "Kaar", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1958, 10, 22) });
        lstNames.Items.Add(new Person { Firstname = "Ingrid", Lastname = "Kieweg", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1975, 11, 21) });
        lstNames.Items.Add(new Person { Firstname = "Daniela", Lastname = "Maier", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1974, 2, 1) });
        lstNames.Items.Add(new Person { Firstname = "Daniela", Lastname = "Aichmayr", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1940, 3, 8) });
        lstNames.Items.Add(new Person { Firstname = "Herwig", Lastname = "Brandstätter", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1976, 7, 15) });
        lstNames.Items.Add(new Person { Firstname = "Hannes", Lastname = "Gutenbrunner", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1955, 2, 2) });
        lstNames.Items.Add(new Person { Firstname = "Karin", Lastname = "Huber", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1969, 3, 13) });
        lstNames.Items.Add(new Person { Firstname = "Bettina", Lastname = "Pichler", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1944, 10, 8) });
        lstNames.Items.Add(new Person { Firstname = "Fred", Lastname = "Fischer", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1948, 3, 21) });
        lstNames.Items.Add(new Person { Firstname = "Sabine", Lastname = "Glaser", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1948, 9, 6) });
        lstNames.Items.Add(new Person { Firstname = "Johann", Lastname = "Gruber", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1972, 5, 11) });
        lstNames.Items.Add(new Person { Firstname = "Peter", Lastname = "Haslehner", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1954, 8, 16) });
        lstNames.Items.Add(new Person { Firstname = "Susanne", Lastname = "Moser", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1958, 2, 26) });
        lstNames.Items.Add(new Person { Firstname = "Gerhard", Lastname = "Pamminger", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1960, 11, 12) });
        lstNames.Items.Add(new Person { Firstname = "Daniela", Lastname = "Puchner", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1943, 7, 7) });
        lstNames.Items.Add(new Person { Firstname = "Josef", Lastname = "Riemer", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1983, 6, 11) });
        lstNames.Items.Add(new Person { Firstname = "Erich", Lastname = "Salzner", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1963, 8, 27) });
        lstNames.Items.Add(new Person { Firstname = "Thomas", Lastname = "Moss", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1987, 10, 17) });
        lstNames.Items.Add(new Person { Firstname = "Karl", Lastname = "Vokal", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1979, 8, 15) });
        lstNames.Items.Add(new Person { Firstname = "Franz", Lastname = "Wang", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1985, 7, 1) });
        lstNames.Items.Add(new Person { Firstname = "Janine", Lastname = "Labrune", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1952, 12, 24) });
        lstNames.Items.Add(new Person { Firstname = "Martine", Lastname = "Rancé", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1975, 11, 25) });
        lstNames.Items.Add(new Person { Firstname = "Maria", Lastname = "Larsson", IsMale = false, HasDriversLicence = false, Birthdate = new DateTime(1990, 12, 26) });
        lstNames.Items.Add(new Person { Firstname = "Carine", Lastname = "Schmitt", IsMale = false, HasDriversLicence = true, Birthdate = new DateTime(1969, 10, 19) });
        lstNames.Items.Add(new Person { Firstname = "Paolo", Lastname = "Accorti", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1983, 2, 7) });
        lstNames.Items.Add(new Person { Firstname = "Fred", Lastname = "Glas", IsMale = true, HasDriversLicence = true, Birthdate = new DateTime(1969, 10, 4) });
        lstNames.Items.Add(new Person { Firstname = "Fritz", Lastname = "Friedmann", IsMale = true, HasDriversLicence = false, Birthdate = new DateTime(1960, 3, 18) });
      }
    }

    private void SelectMultiplePersons()
    {
      lstNames.SelectionMode = SelectionMode.Multiple;
      lstNames.SelectedItems.Add(lstNames.Items[0]);
      lstNames.SelectedItems.Add(lstNames.Items[2]);
    }
    #endregion

    private void LstNames_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (lstNames.SelectedItem is not Person person) return;
      txtFirstname.Text = person.Firstname;
      txtLastname.Text = person.Lastname;
      dtpBorn.SelectedDate = person.Birthdate;
      (person.IsMale ? rdoMale : rdoFemale).IsChecked = true;
      chkDriversLicence.IsChecked = person.HasDriversLicence;
    }
    private void LstNames_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      //due to SelectionMode="Multiple" clear all other selections first
      //lstNames.SelectedItems.Clear();
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
      int idx = lstNames.SelectedIndex;
      if (idx < 0) return;
      lstNames.Items.RemoveAt(idx);
    }

    private void TxtSearch_KeyUp(object sender, KeyEventArgs e) => PopulateNameDict();
    private void SearchFieldChanged(object sender, RoutedEventArgs e) => PopulateNameDict();

    private void PopulateNameDict()
    {
      string txt = txtSearch.Text.ToLower();
      var nameDict = new SortedDictionary<string, List<Person>>();
      foreach (var item in lstNames.Items)
      {
        if (item is not Person person) continue;
        string key = rdoFirstname.IsChecked == true ? person.Firstname : person.Lastname;
        if (!key.ToLower().StartsWith(txt)) continue;
        if (!nameDict.ContainsKey(key)) nameDict[key] = new List<Person>();
        nameDict[key].Add(person);
      }
      if (lstSearchNames == null) return;
      lstSearchNames.Items.Clear();
      foreach (var entry in nameDict)
      {
        lstSearchNames.Items.Add($"{entry.Key} ({entry.Value.Count})");
      }
    }

    private void LstSearchNames_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
      if (lstNames.SelectionMode != SelectionMode.Multiple) return;
      if (lstSearchNames.SelectedItem is not string sel) return;
      string name = sel.Split(' ')[0];
      var selected = new List<Person>();
      lstNames.SelectedItems.Clear();
      foreach (Person person in lstNames.Items)
      {
        string key = rdoFirstname.IsChecked == true ? person.Firstname : person.Lastname;
        if (key == name) selected.Add(person);
      }
      foreach (var person in selected)
      {
        lstNames.SelectedItems.Add(person);
      }
    }

  }
}
