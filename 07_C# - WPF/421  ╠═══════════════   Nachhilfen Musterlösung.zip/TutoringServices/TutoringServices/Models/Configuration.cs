﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace TutoringServices.Models
{
  public class Configuration
  {
    public static List<Student> Students { get; private set; }
    public static List<string> Subjects { get; private set; }
    public static int[] Levels { get; }

    static Configuration()
    {
      Levels = Enumerable.Range(1, 5).ToArray();
      InitSubjects();
      InitStudents();
    }

    private static void InitSubjects()
    {
      Subjects = new();
      var lines = File.ReadAllLines(@"csv\subjects.csv");
      Subjects.AddRange(lines[0].Split(';').Select(x => x.Trim().ToUpper()));
      Console.WriteLine($"Loaded Subjects: {string.Join(", ", Subjects)}");
    }

    private static void InitStudents()
    {
      Students = File.ReadAllLines(@"csv\students.csv")
        .Select(Student.Parse)
        .Where(x => x != null)
        .OrderBy(x => x.Lastname)
        .ToList();
      Console.WriteLine($"Loaded Students: {Students.Count} students");
    }
  }
}
