﻿namespace TutoringServices.Models
{
  public class Service
  {
    public string Subject { get; set; }
    public int Level { get; set; }
    public override string ToString() => $"{Subject} in {Level}.Klassen";
  }
}