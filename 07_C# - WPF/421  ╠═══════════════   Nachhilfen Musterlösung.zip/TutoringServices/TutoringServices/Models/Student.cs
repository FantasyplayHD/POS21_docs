﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace TutoringServices.Models
{
  public class Student
  {
    public string Firstname { get; set; }
    public string Lastname { get; set; }
    public string Name => $"{Lastname} {Firstname}";
    public string ImagePath => $@"./Images/{Lastname}_{Firstname}.jpg";

    public string Clazz { get; set; }
    public List<Service> Services { get; set; } = new();
    public override string ToString() => Name;

    public static Student Parse(string line)
    {
      const string pattern = @"(?<clazz>\d[abcmABCM]);(?<last>[a-zA-ZßöäüÄÖÜ\-]{2,})\s+(?<first>[a-zA-ZöäüÄÖÜ\-]{2,})";
      var match = Regex.Match(line, pattern);
      if (!match.Success) return null;
      return new Student
      {
        Firstname = match.Groups["first"].Value,
        Lastname = match.Groups["last"].Value,
        Clazz = match.Groups["clazz"].Value
      };

    }
  }
}
