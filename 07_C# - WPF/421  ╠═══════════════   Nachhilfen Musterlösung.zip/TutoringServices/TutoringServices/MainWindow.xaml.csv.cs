﻿using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using TutoringServices.Models;

namespace TutoringServices
{
  public partial class MainWindow : Window
  {
    private static void ReadTutoringsFromCsv(string fileName)
    {
      if (!File.Exists(fileName)) return;
      var lines = File.ReadAllLines(fileName, Encoding.GetEncoding("ISO-8859-1"));
      foreach (string line in lines)
      {
        string[] items = line.Split(';');
        string studentName = items[0];
        Configuration.Students
          .FirstOrDefault(x => x.Name == studentName)?
          .Services?
          .Add(new Service
          {
            Subject = items[1],
            Level = int.Parse(items[2])
          });
      }
    }

    private static void WriteTutoringsCsv(string fileName)
    {
      var writer = new StreamWriter(fileName, false, Encoding.GetEncoding("ISO-8859-1"));
      foreach (var student in Configuration.Students.Where(x => x.Services.Any()))
      {
        foreach (var service in student.Services)
        {
          writer.WriteLine($"{student.Name};{service.Subject};{service.Level}");
        }
      }
      writer.Close();
    }
  }
}
