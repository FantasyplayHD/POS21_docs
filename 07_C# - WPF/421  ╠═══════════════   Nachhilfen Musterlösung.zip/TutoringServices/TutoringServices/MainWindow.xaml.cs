﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using TutoringServices.Models;

namespace TutoringServices
{
  public partial class MainWindow : Window
  {
    private const string TUTORINGS_FILENAME = @"csv\tutorings.csv";
    private readonly string initialDirectory;

    public MainWindow()
    {
      InitializeComponent();
      initialDirectory = Path.GetDirectoryName(GetType().Assembly.Location);
    }

    #region -------------------------------------------------------- Init
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      CheckUnusedImages();
      var displayedStudents = Configuration.Students;
      PopulateClazzes(displayedStudents);
      PopulateLevels();
      PopulateSubjects();
      PopulateStudents();
      //AddSomeTutorings();
      ReadTutoringsFromCsv(Path.Combine(initialDirectory, TUTORINGS_FILENAME));
      LoadInitialData();
    }

    private void LoadInitialData() => cboNames.SelectedItem = Configuration.Students.FirstOrDefault(x => x.Lastname == "Mair");

    private static void CheckUnusedImages()
    {
      var imageFileNames = Directory.GetFiles(@".\Images").Select(x => new FileInfo(x).Name);
      var studentsAsImagenames = File.ReadAllLines(@"csv\students.csv").Select(Student.Parse).Where(x => x != null).Select(x => $"{x.Lastname}_{x.Firstname}.jpg");
      var imageFilesNotused = imageFileNames.Except(studentsAsImagenames);
      var studentsWithoutImage = studentsAsImagenames.Except(imageFileNames);
      if (imageFilesNotused.Any()) MessageBox.Show(string.Join('\n', imageFilesNotused), "Unused images");
      if (studentsWithoutImage.Any()) MessageBox.Show(string.Join('\n', studentsWithoutImage), "Students without image file");
    }

    private void AddSomeTutorings()
    {
      var student = cboNames.Items[0] as Student;
      student?.Services.Add(new Service { Subject = "M", Level = 3 });
    }

    private void InitDialog(FileDialog dialog)
    {
      dialog.DefaultExt = "csv";
      dialog.FileName = TUTORINGS_FILENAME;
      dialog.Filter = "CSV files|*.csv|All files|*.*";
      dialog.InitialDirectory = initialDirectory; //@"C:\Temp"
    }
    #endregion

    #region -------------------------------------------------------- Populate
    private void PopulateStudents(IEnumerable<string> clazzesExcluded = null)
    {
      var students = Configuration.Students;
      if (clazzesExcluded != null)
      {
        foreach (string clazz in clazzesExcluded)
        {
          students = students.Where(x => x.Clazz != clazz).ToList();
        }
      }
      cboNames.ItemsSource = students;
      cboNames.Items.Refresh();
      cboNames.SelectedIndex = 0;
    }

    private void PopulateClazzes(IEnumerable<Student> students)
    {
      foreach (string clazz in students.Select(x => x.Clazz).Distinct().OrderBy(x => x))
      {
        var chk = new CheckBox
        {
          Content = clazz,
          Margin = new Thickness(5, 0, 5, 0),
          IsChecked = true
        };
        chk.Checked += ChkClazz_OnCheckChanged;
        chk.Unchecked += ChkClazz_OnCheckChanged;
        tbrMain.Items.Add(chk);
      }
    }
    private void PopulateLevels() => PopuplatePanel(panLevels, Configuration.Levels);
    private void PopulateSubjects() => PopuplatePanel(panSubjects, Configuration.Subjects);
    private static void PopuplatePanel<T>(Panel panel, IEnumerable<T> items)
    {
      int nr = 0;
      foreach (var item in items)
      {
        panel.Children.Add(new RadioButton { Content = item.ToString(), IsChecked = nr++ == 0 });
      }
    }
    #endregion

    #region -------------------------------------------------------- Events
    private void ChkClazz_OnCheckChanged(object sender, RoutedEventArgs routedEventArgs)
    {
      PopulateStudents(tbrMain.Items.OfType<CheckBox>()
        .Where(x => x.IsChecked == false)
        .Select(x => x.Content.ToString()));
    }

    private void CboNames_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (cboNames.SelectedItem is not Student student) return;
      lblName.Content = student.Name;
      imgStudent.Source = CreateImageForStudent(student);
      lstServices.ItemsSource = student.Services;
      lblServiceCount.Content = student.Services.Count;
    }


    private void BtnAdd_OnClick(object sender, RoutedEventArgs e)
    {
      if (cboNames.SelectedItem is not Student student) return;
      student.Services.Add(new Service
      {
        Subject = GetCheckedSubject(),
        Level = GetCheckedLevel()
      });
      lstServices.ItemsSource = student.Services;
      lstServices.Items.Refresh();
      lblServiceCount.Content = student.Services.Count;
    }

    private void MnuLoad_Click(object sender, RoutedEventArgs e)
    {
      var dialog = new OpenFileDialog();
      InitDialog(dialog);
      if (true != dialog.ShowDialog()) return;
      ReadTutoringsFromCsv(dialog.FileName);
    }

    private void MnuSave_Click(object sender, RoutedEventArgs e)
    {
      var dialog = new SaveFileDialog();
      InitDialog(dialog);
      if (true != dialog.ShowDialog()) return;
      WriteTutoringsCsv(dialog.FileName);
    }
    #endregion

    #region -------------------------------------------------------- Helpers
    private static BitmapImage CreateImageForStudent(Student student)
    {
      //return new BitmapImage(new Uri($@"C:\_PR\CSharp\PR4\141_TutoringServices\TutoringServices\bin\Debug\Images\{student.Lastname}_{student.Firstname}.jpg", UriKind.Absolute));
      var image = new BitmapImage();
      image.BeginInit();
      image.UriSource = new Uri(student.ImagePath, UriKind.Relative);
      image.CacheOption = BitmapCacheOption.OnLoad; //http://stackoverflow.com/questions/569561/dynamic-loading-of-images-in-wpf
      image.EndInit();
      return image;
    }

    public int GetCheckedLevel()
    {
      foreach (RadioButton radio in panLevels.Children)
      {
        if (radio.IsChecked == true) return int.Parse(radio.Content.ToString());
      }
      return 0;
    }

    private string GetCheckedSubject()
    {
      foreach (RadioButton radio in panSubjects.Children)
      {
        if (radio.IsChecked == true) return radio.Content.ToString();
      }
      return "PR";
    }
    #endregion
  }
}
