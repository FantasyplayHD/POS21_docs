﻿using System;
using System.Diagnostics;
using System.IO;

namespace Regalsystem
{
  class Program
  {
    static void Main()
    {
      var regal = new Regal(6, 5);
      FillWithTestData(regal);
      regal.Anzeigen();
      Test();
      Console.ReadKey();
    }

    private static void FillWithTestData(Regal regal)
    {
      Console.WriteLine("FillWithTestData");
      regal.Lagern(2, 2, new Werkzeug(1) { Gewicht = 12.4 });
      regal.Lagern(4, 1, new Werkzeug(2) { Gewicht = 2.6 });
      regal.Lagern(2, 3, new Werkzeug(3) { Gewicht = 9.1 });
      regal.Lagern(1, 4, new Buch(4, 20, 15, 4));
      regal.Lagern(2, 3, new Buch(5, 18, 15, 5));
      regal.Lagern(3, 1, new Buch(6, 24, 13, 9));
      regal.Lagern(4, 4, new Buch(7, 21, 12, 12));
      regal.Lagern(5, 4, new Buch(8, 20, 16, 6));
      regal.Lagern(5, 4, new Buch(8, 20, 16, 6));
      regal.Lagern(new Werkzeug(9) { Gewicht = 9.9 });
      //regal.Lagern(new Werkzeug(9, 9.9));
      //regal.Lagern(new Werkzeug(9, 9.9));
    }

    private static void Test()
    {
      //better done within a real unit test...
      const string FILE_NAME = "waren.csv"; //CSV-File is part of project with property "Copy To Output Dir" set to "Copy If Newer"
      var regal = new Regal(6, 5);

      string[] lines = File.ReadAllLines(FILE_NAME);
      foreach (string line in lines)
      {
        if (line == null || line.Trim().Length == 0) continue;
        string[] items = line.Split(';');
        int id = int.Parse(items[3]);
        int row = int.Parse(items[1]);
        int col = int.Parse(items[2]);
        var ware = items[0].Equals("Werkzeug")
          ? (Ware)new Werkzeug(id) { Gewicht = double.Parse(items[4]) }
          : (Ware)new Buch(id, int.Parse(items[4]), int.Parse(items[5]), int.Parse(items[6]));
        regal.Lagern(row, col, ware);
      }
      double expected = 23.33;
      double actual = regal.Auslastung();
      if (expected == actual) Console.WriteLine($"Test Ok");
      else Console.WriteLine($"Test failed: expected {expected} but was {actual}");
    }
  }
}
