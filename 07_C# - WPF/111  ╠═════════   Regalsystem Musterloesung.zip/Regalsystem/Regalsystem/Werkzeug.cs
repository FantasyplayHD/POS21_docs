﻿namespace Regalsystem
{
  public class Werkzeug : Ware
  {
    //private double gewicht;
    //public Werkzeug(int id, double gewicht) : base(id)
    //{
    //  this.gewicht = gewicht;
    //}

    //version with properties instead of constructor parameters
    public Werkzeug(int id) : base(id) { }

    public double Gewicht { get; set; }

    public override string Beschreibung => $"#{id}: {nameof(Werkzeug)} {Gewicht} kg";

    public override string KurzZeichen => "W";
  }
}
