﻿namespace Regalsystem
{
  public class Buch : Ware
  {
    //version with constructor parameters instead of properties
    private readonly int laenge;
    private readonly int breite;
    private readonly int hoehe;
    public Buch(int id, int laenge, int breite, int hoehe) : base(id)
    {
      this.laenge = laenge;
      this.breite = breite;
      this.hoehe = hoehe;
    }

    public override string Beschreibung => $"#{id}: {nameof(Buch)} {laenge}x{breite}x{hoehe}";

    public override string KurzZeichen => "B";
  }
}
