﻿namespace Regalsystem
{
  public abstract class Ware
  {
    protected int id;

    protected Ware(int id) => this.id = id;

    //use abstract property instead of abstract method
    public abstract string Beschreibung { get; }
    public abstract string KurzZeichen { get; }
  }
}
