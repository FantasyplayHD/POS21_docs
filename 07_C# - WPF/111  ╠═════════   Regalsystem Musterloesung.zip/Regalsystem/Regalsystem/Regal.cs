﻿using System;

namespace Regalsystem
{
  public class Regal
  {
    private readonly Ware[,] data;
    public Regal(int nrRows, int nrCols)
    {
      data = new Ware[nrRows, nrCols];
      NrRows = nrRows;
      NrCols = nrCols;
    }

    public int NrRows { get; private set; } //to avoid usage of data.GetLength(0)
    public int NrCols { get; private set; } //to avoid usage of data.GetLength(1)

    public bool Lagern(int row, int col, Ware ware)
    {
      var currentWare = data[row, col];
      if (currentWare != null)
      {
        Console.WriteLine($"Fach {row}/{col} besetzt --> {currentWare.Beschreibung}");
        return false;
      }
      data[row, col] = ware;
      return true;
    }

    public void Lagern(Ware ware)
    {
      for (int i = 0; i < NrRows; i++) //or i< data.GetLength(0)
      {
        for (int j = 0; j < NrCols; j++) //or j<data.GetLength(1)
        {
          if (data[i, j] == null)
          {
            Lagern(i, j, ware);
            return;
          }
        }
      }
    }

    public Ware Ausliefern(int row, int col)
    {
      var ware = data[row, col];
      data[row, col] = null;
      return ware;
    }

    private void PrintLine()
    {
      Console.WriteLine();
      for (int j = 0; j < NrCols; j++)
      {
        Console.Write("----");
      }
      Console.WriteLine("-");
    }

    public void Anzeigen()
    {
      PrintLine();
      for (int i = 0; i < NrRows; i++)
      {
        Console.Write("| ");
        for (int j = 0; j < NrCols; j++)
        {
          string s = (data[i, j] != null) ? data[i, j].KurzZeichen : " ";
          Console.Write($"{s} | ");
        }
        PrintLine();
      }
      Console.WriteLine($"Auslastung: {Auslastung()} %");
    }

    public double Auslastung()
    {
      //int nrRows = data.GetLength(0);
      //int nrCols = data.GetLength(1);
      int nr = 0;
      for (int i = 0; i < NrRows; i++)
      {
        for (int j = 0; j < NrCols; j++)
        {
          if (data[i, j] != null) nr++;
        }
      }
      double nrCells = NrRows * NrCols;
      double perc = nr * 100 / nrCells;
      return (int)(perc * 100) / 100.0;
    }
  }

}
