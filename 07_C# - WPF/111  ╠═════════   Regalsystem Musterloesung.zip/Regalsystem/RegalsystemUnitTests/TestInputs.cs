﻿using System;
using System.IO;
using Regalsystem;
using Xunit;

namespace RegalsystemUnitTests
{
  public class TestInputs
  {
    [Fact]
    public void TestAverage()
    {
      const string FILE_NAME = "waren.csv"; //CSV-File is part of project with property "Copy To Output Dir" set to "Copy If Newer"
      var regal = new Regal(6, 5);
      try
      {
        string[] lines = File.ReadAllLines(FILE_NAME);
        foreach (string line in lines)
        {
          if (line == null || line.Trim().Length == 0) continue;
          string[] items = line.Split(';');
          int id = int.Parse(items[3]);
          int row = int.Parse(items[1]);
          int col = int.Parse(items[2]);
          var ware = items[0].Equals("Werkzeug")
            ? (Ware)new Werkzeug(id) { Gewicht = double.Parse(items[4]) }
            : (Ware)new Buch(id, int.Parse(items[4]), int.Parse(items[5]), int.Parse(items[6]));
          regal.Lagern(row, col, ware);
        }
        Assert.Equal(23.33, regal.Auslastung(), 3);
      }
      catch (Exception exc)
      {
        Assert.False(true, exc.Message);
      }
    }
  }
}
