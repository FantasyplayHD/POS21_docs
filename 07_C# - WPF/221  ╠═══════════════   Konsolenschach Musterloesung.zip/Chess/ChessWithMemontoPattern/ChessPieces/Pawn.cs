﻿using System;

namespace ChessWithMemontoPattern.ChessPieces
{
  [Serializable]
  public class Pawn : ChessPiece
  {
    public Pawn(bool isWhite, int column, int line) : base(isWhite, column, line)
    {
      shortName = "B";
      symbol = isWhite ? "\u2659 " : "\u265F";
      longName = "Bauer";
    }

    public override bool CanMove(int columnTo, int lineTo, ChessBoard board)
    {
      int lineForward = IsWhite ? Line + 1 : Line - 1;
      int lineForForward = IsWhite ? Line + 2 : Line - 2;

      //check pawn beats other chess piece
      int columnDiff = Math.Abs(Column - columnTo);
      if (columnDiff == 1 && lineTo == lineForward) return board.GetPieceAtPosition(columnTo, lineTo) != null;

      return CheckMoveForward(columnTo, lineTo, lineForward, lineForForward, board);
    }

    private bool CheckMoveForward(int columnTo, int lineTo, int lineForward, int lineForForward, ChessBoard board)
    {
      bool isMoveInSameColumn = Column == columnTo;
      if (!isMoveInSameColumn) return false;
      if (lineTo == lineForward) return board.GetPieceAtPosition(columnTo, lineTo) == null; //target field must be empty
      int baseLine = IsWhite ? ChessBoard.FIRST_LINE + 1 : ChessBoard.LAST_LINE - 1;
      if (lineTo == lineForForward) return Line == baseLine
          && board.GetPieceAtPosition(columnTo, lineForward) == null
          && board.GetPieceAtPosition(columnTo, lineForForward) == null;
      return false;
    }
  }
}
