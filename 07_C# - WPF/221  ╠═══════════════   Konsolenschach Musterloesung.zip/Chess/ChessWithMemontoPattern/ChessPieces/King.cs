﻿using System;

namespace ChessWithMemontoPattern.ChessPieces
{
  [Serializable]
  public class King : ChessPiece
  {
    public King(bool isWhite, int column, int line) : base(isWhite, column, line)
    {
      shortName = "K";
      symbol = isWhite ? "\u2654 " : "\u265A ";
      longName = "König";
    }

    public override bool CanMove(int columnTo, int lineTo, ChessBoard board)
      => Math.Abs(columnTo - Column) <= 1 && Math.Abs(lineTo - Line) <= 1;

  }
}
