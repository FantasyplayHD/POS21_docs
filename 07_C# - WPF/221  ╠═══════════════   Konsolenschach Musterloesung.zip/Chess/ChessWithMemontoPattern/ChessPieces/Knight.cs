﻿using System;

namespace ChessWithMemontoPattern.ChessPieces
{
  [Serializable]
  public class Knight : ChessPiece
  {
    public Knight(bool isWhite, int column, int line) : base(isWhite, column, line)
    {
      shortName = "S";
      symbol = isWhite ? "\u2658 " : "\u265E ";
      longName = "Springer";
    }

    public override bool CanMove(int columnTo, int lineTo, ChessBoard board)
      => (columnTo - Column) * (columnTo - Column) + (lineTo - Line) * (lineTo - Line) == 5;

  }
}
