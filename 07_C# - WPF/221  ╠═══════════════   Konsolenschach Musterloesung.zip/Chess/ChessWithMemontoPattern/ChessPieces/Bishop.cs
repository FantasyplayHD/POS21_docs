﻿using System;

namespace ChessWithMemontoPattern.ChessPieces
{
  [Serializable]
  public class Bishop : ChessPiece
  {
    public Bishop(bool isWhite, int column, int line) : base(isWhite, column, line)
    {
      shortName = "L";
      symbol = isWhite ? "\u2657 " : "\u265D ";
      longName = "Läufer";
    }

    public override bool CanMove(int columnTo, int lineTo, ChessBoard board)
    {
      (int lineFromChecked, int lineToChecked) = GetRange(Line, lineTo);
      (int columnFromChecked, int columnToChecked) = GetRange(Column, columnTo);
      int columnSteps = columnToChecked - columnFromChecked;
      int lineSteps = lineToChecked - lineFromChecked;
      if (columnSteps != lineSteps) return false;
      for (int i = 1; i < lineSteps; i++)
      {
        if (board.GetPieceAtPosition(columnFromChecked + i, lineFromChecked + i) != null) return false;
      }
      return true;
    }

    (int, int) GetRange(int valA, int valB) => (Math.Min(valA, valB), Math.Max(valA, valB));
  }
}
