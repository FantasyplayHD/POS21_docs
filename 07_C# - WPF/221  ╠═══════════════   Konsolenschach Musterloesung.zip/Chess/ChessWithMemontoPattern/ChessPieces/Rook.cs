﻿using System;

namespace ChessWithMemontoPattern.ChessPieces
{
  [Serializable]
  public class Rook : ChessPiece
  {
    public Rook(bool isWhite, int column, int line) : base(isWhite, column, line)
    {
      shortName = "T";
      symbol = isWhite ? "\u2656 " : "\u265C ";
      longName = "Turm";
    }
    public override bool CanMove(int columnTo, int lineTo, ChessBoard board)
    {
      if (Column == columnTo) return CheckMoveInSameColumn(lineTo, board);
      if (Line == lineTo) return CheckMoveInSameLine(columnTo, board);
      return false;
    }

    private bool CheckMoveInSameLine(int columnTo, ChessBoard board)
    {
      (int from, int to) = CalcMinMax(Column, columnTo);
      for (int column = from + 1; column < to; column++)
      {
        if (board.GetPieceAtPosition(column, Line) != null) return false;
      }
      return true;
    }

    private bool CheckMoveInSameColumn(int lineTo, ChessBoard board)
    {
      (int from, int to) = CalcMinMax(Line, lineTo);
      for (int line = from + 1; line < to; line++)
      {
        if (board.GetPieceAtPosition(Column, line) != null) return false;
      }
      return true;
    }

    (int, int) CalcMinMax(int from, int to) => (Math.Min(from, to), Math.Max(from, to));
  }
}
