﻿using System;

namespace ChessWithMemontoPattern.ChessPieces
{
  [Serializable]
  public class Queen : ChessPiece
  {
    private static Rook rook;     //a queen can move like a rook or a bishop
    private static Bishop bishop;
    public Queen(bool isWhite, int column, int line) : base(isWhite, column, line)
    {
      shortName = "D";
      symbol = isWhite ? "\u2655 " : "\u265B ";
      longName = "Dame";
    }
    public override bool CanMove(int columnTo, int lineTo, ChessBoard board)
    {
      if (rook == null) rook = new Rook(IsWhite, 0, 0);
      if (bishop == null) bishop = new Bishop(IsWhite, 0, 0);
      rook.Line = Line;
      rook.Column = Column;
      bishop.Line = Line;
      bishop.Column = Column;
      return rook.CanMove(columnTo, lineTo, board) || bishop.CanMove(columnTo, lineTo, board);
    }
  }
}
