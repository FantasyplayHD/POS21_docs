﻿using System;

namespace ChessWithMemontoPattern.ChessPieces
{
  [Serializable]
  public abstract class ChessPiece
  {
    private readonly string prefix;
    protected string shortName = " ";
    protected string symbol = " ";
    protected string longName = "";

    protected ChessPiece() { }
    protected ChessPiece(bool isWhite, int column, int line)
    {
      IsWhite = isWhite;
      prefix = isWhite ? "w" : "s";
      Line = line;
      Column = column;
    }

    public int Column { get; set; }
    public int Line { get; set; }
    public virtual bool IsWhite { get; private set; }
    public virtual bool IsBlack => !IsWhite;
    public string FullName => $"{longName} ({(IsWhite ? "weiß" : "schwarz")})";

    public override string ToString() => $"{symbol}";//$"{prefix}{shortName}";

    public abstract bool CanMove(int columnTo, int lineTo, ChessBoard board);
    //consider also: make Chessboard a property of class ChessPiece to avoid passing ChessBoard as parameter to many methods

    public void Render()
    {
      var writer = new ColorWriter
      {
        //ForegroundColor = IsWhite ? ConsoleColor.Black : ConsoleColor.White,
        //BackgroundColor = IsWhite ? ConsoleColor.White : ConsoleColor.Black
        ForegroundColor = IsWhite ? ConsoleColor.White : ConsoleColor.Black,
        BackgroundColor = ConsoleColor.Gray
      };
      writer.Write(this);
    }
  }
}
