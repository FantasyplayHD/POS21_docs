﻿using ChessWithMemontoPattern.ChessPieces;
using System;
using System.Linq;

namespace ChessWithMemontoPattern
{
  public partial class ChessBoard
  {
    public void Move(string sMove)
    {
      if (!sMove.Contains('-')) throw new ImpossibleMoveException($"Invalid move-string <{sMove}>");
      var positions = sMove.ToLower().Split('-');
      string from = positions[0].Trim();
      string to = positions[1].Trim();
      if (from.Length != 2) throw new ImpossibleMoveException($"Invalid Start-Position <{from}>");
      if (to.Length != 2) throw new ImpossibleMoveException($"Invalid End-Position <{to}>");
      Move(from, to);
    }

    private void Move(string from, string to)
    {
      int columnFrom = from[0] - 'a' + 1; //[1,...,8]
      int lineFrom = from[1] - '0';
      int columnTo = to[0] - 'a' + 1;
      int lineTo = to[1] - '0';
      CheckInput(from, to, columnFrom, lineFrom, columnTo, lineTo);
      ClearTargetPosition(columnTo, lineTo);
      PerformMoveToEmptyField(columnFrom, lineFrom, columnTo, lineTo);
    }

    private void PerformMoveToEmptyField(int columnFrom, int lineFrom, int columnTo, int lineTo)
    {
      var pieceToMove = GetPieceAtPosition(columnFrom, lineFrom);
      pieceToMove.Column = columnTo;
      pieceToMove.Line = lineTo;
      isWhiteToMove = !isWhiteToMove;
      nrMoves++;
    }

    private void ClearTargetPosition(int columnTo, int lineTo)
    {
      var pieceeAtTarget = GetPieceAtPosition(columnTo, lineTo);
      if (pieceeAtTarget == null) return;
      Console.WriteLine($"Remove piece {pieceeAtTarget}");
      board.Remove(pieceeAtTarget);
    }

    public ChessPiece GetPieceAtPosition(int column, int line)
    {
      foreach (var piece in board)
      {
        if (piece.Column == column && piece.Line == line) return piece;
      }
      return null;
    }

    private void CheckInput(string from, string to, int columnFrom, int lineFrom, int columnTo, int lineTo)
    {
      if (lineFrom <= 0 || lineFrom > LAST_LINE || columnFrom <= 0 || columnFrom > LAST_COLUMN) throw new ImpossibleMoveException($"Invalid source position <{from}>");
      if (lineTo <= 0 || lineTo > LAST_LINE || columnTo <= 0 || columnTo > LAST_COLUMN) throw new ImpossibleMoveException($"Invalid target position <{to}>");
      var pieceAtTarget = GetPieceAtPosition(columnTo, lineTo);
      var pieceToMove = GetPieceAtPosition(columnFrom, lineFrom);
      if (pieceToMove == null) throw new ImpossibleMoveException($"No piece at {from}");
      if (pieceToMove != null && isWhiteToMove != pieceToMove.IsWhite) throw new ImpossibleMoveException($"No {(isWhiteToMove ? "white" : "black")} piece at {from}");
      if (pieceAtTarget != null && (isWhiteToMove && pieceAtTarget.IsWhite || !isWhiteToMove && pieceAtTarget.IsBlack)) throw new ImpossibleMoveException($"Own piece at {to}");

      CheckMoveIsPossible(to, columnTo, lineTo, pieceToMove);
    }

    private void CheckMoveIsPossible(string to, int columnTo, int lineTo, ChessPiece pieceToMove)
    {
      if (!pieceToMove.CanMove(columnTo, lineTo, this))
      {
        throw new ImpossibleMoveException($"{pieceToMove.FullName} cannot move to {to}!");
      }
    }
  }
}
