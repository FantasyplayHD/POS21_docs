﻿using System;

namespace ChessWithMemontoPattern
{
  internal class Program
  {
    private static ChessBoard board;

    static void Main(string[] args)
    {
      Console.OutputEncoding = System.Text.Encoding.UTF8;
      //also don't forget to set font of console to MSGothic if using Unicode symbols for chess pieces
      board = new ChessBoard().Init();
      PerformInitialMoves();
      bool allOk = new MoveTester().Test();
      if (!allOk)
      {
        Console.WriteLine("Errors should be fixed before playing");
        Console.ReadKey();
      }
      Play();
    }

    private static void PerformInitialMoves()
    {
      board.Move("e2-e4");
      board.Move("e7-e5");
      board.Move("d2-d4");
      board.Move("g7-g6");
      board.Move("b1-c3");
      board.Move("g8-f6");
    }

    private static void Play()
    {
      while (true)
      {
        try
        {
          RenderHelpInfo();
          string move = ReadNextMove();
          if (move == null) continue;
          if (move.ToLower().Equals("exit")) break;
          HandleMove(move);
        }
        catch (Exception exc)
        {
          DisplayError(exc.Message);
        }
      }
    }

    private static void HandleMove(string move)
    {
      if (move.StartsWith("-"))
      {
        if (!int.TryParse(move.TrimStart('-'), out int stepsBack)) stepsBack = 1;
      }
      else if (move.StartsWith("+"))
      {
        if (!int.TryParse(move.TrimStart('-'), out int stepsForth)) stepsForth = 1;
      }
      else
      {
        board.Move(move);
      }
    }

    private static string ReadNextMove()
    {
      string sColorToMove = board.IsNextMoveWhite ? "weiß   " : "schwarz";
      Console.Write($"{board.MoveNr}. Zug {sColorToMove}: ");
      string move = Console.ReadLine();
      return move;
    }

    private static void DisplayError(string msg)
    {
      var writer = new ColorWriter { BackgroundColor = ConsoleColor.Red };
      writer.WriteLine($"{msg.PadLeft(10, '*')} (Press key to continue)");
      Console.ReadKey();
    }

    private static void RenderHelpInfo()
    {
      Console.Clear();
      board.Render();
      Console.WriteLine("Zug eingeben in der Form: e2-e4");
      Console.WriteLine("Eingabe Exit um zu beenden");
      Console.WriteLine("Eingabe -x um x Züge zurückzunehmen, z.B. -3 nimmt 3 Züge zurück");
      Console.WriteLine("Eingabe +x um x Züge erneut auszuführen, z.B. +3 führt die letzten 3 zurückgenommen Züge erneut aus");
    }
  }
}
