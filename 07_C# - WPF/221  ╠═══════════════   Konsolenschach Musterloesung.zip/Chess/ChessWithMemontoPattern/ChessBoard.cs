﻿using ChessWithMemontoPattern.ChessPieces;
using System;
using System.Collections.Generic;

namespace ChessWithMemontoPattern
{
  public partial class ChessBoard
  {
    #region Variables
    private const int BOARD_LEN = 41;
    private const int CELL_WIDTH_WITHOUT_BORDER = 4;
    public const int FIRST_LINE = 1, LAST_LINE = 8;
    public const int FIRST_COLUMN = 1, LAST_COLUMN = 8;
    private static List<ChessPiece> board;
    private bool isWhiteToMove;
    private int nrMoves;

    private readonly ColorWriter whiteOnBlack = new ColorWriter
    {
      BackgroundColor = ConsoleColor.Black,
      ForegroundColor = ConsoleColor.White
    };
    private readonly ColorWriter blackOnWhite = new ColorWriter
    {
      BackgroundColor = ConsoleColor.White,
      ForegroundColor = ConsoleColor.Black
    };
    private readonly ColorWriter grayOnGray = new ColorWriter
    {
      BackgroundColor = ConsoleColor.Gray,
      ForegroundColor = ConsoleColor.DarkGray
    };
    #endregion

    public bool IsNextMoveWhite => isWhiteToMove;
    public int MoveNr => nrMoves / 2 + 1;

    public ChessBoard()
    {
      nrMoves = 0;
      isWhiteToMove = true;
      board = new List<ChessPiece>();
    }
    public ChessBoard Init()
    {
      const int WHITE = 0;
      const int BLACK = 1;
      for (int i = WHITE; i <= BLACK; i++)
      {
        bool isWhite = i == WHITE;
        int baseLine = i == WHITE ? FIRST_LINE : LAST_LINE;

        board.Add(new Rook(isWhite, 1, baseLine));
        board.Add(new Knight(isWhite, 2, baseLine));
        board.Add(new Bishop(isWhite, 3, baseLine));
        board.Add(new Queen(isWhite, 4, baseLine));
        board.Add(new King(isWhite, 5, baseLine));
        board.Add(new Bishop(isWhite, 6, baseLine));
        board.Add(new Knight(isWhite, 7, baseLine));
        board.Add(new Rook(isWhite, 8, baseLine));

        int secondLine = i == WHITE ? FIRST_LINE + 1 : LAST_LINE - 1;
        for (int column = FIRST_COLUMN; column <= LAST_COLUMN; column++)
        {
          board.Add(new Pawn(isWhite, column, secondLine));
        }
      }
      return this;
    }

    #region Rendering
    public void Render()
    {
      RenderEmptyBoard();
      RenderAllPieces();
      Console.SetCursorPosition(0, LAST_LINE + 11);
    }

    public void RenderEmptyBoard()
    {
      DrawEdgeLine();
      for (int line = LAST_LINE; line >= 1; line--) //display white base line at bottom of the board
      {
        DrawBoardLine(line);
        if (line == 1) continue;
        DrawLimitLine();
      }
      DrawEdgeLine();
      DrawColumnHeadings();
    }

    private void DrawBoardLine(int line)
    {
      string cell = new string(' ', CELL_WIDTH_WITHOUT_BORDER);
      whiteOnBlack.Write(line);
      grayOnGray.Write("|");
      for (int i = 0; i < LAST_COLUMN; i++)
      {
        grayOnGray.Write($"{cell}|");
      }
      Console.WriteLine();
    }

    private void DrawColumnHeadings() => whiteOnBlack.WriteLine("   a    b    c    d    e    f    g    h");
    private void DrawLimitLine()
    {
      whiteOnBlack.Write(" ");
      grayOnGray.WriteLine("|----+----+----+----+----+----+----+----|");
    }
    private void DrawEdgeLine()
    {
      whiteOnBlack.Write(" ");
      grayOnGray.WriteLine("+" + new string('-', BOARD_LEN - 2) + "+");
    }
    public void RenderAllPieces()
    {
      for (int line = LAST_LINE; line >= 1; line--) //display white base line at bottom of the board
      {
        for (int column = 1; column <= LAST_COLUMN; column++)
        {
          RenderChessPiece(column, line);
        }
      }
    }

    private void RenderChessPiece(int column, int line)
    {
      int cellWidth = 5; //includes right border
      int lineOffset = 1;
      int columnOffset = 3;
      var piece = GetPieceAtPosition(column, line);
      if (piece == null) return;
      column--;  //cursor positions are zero based!!
      line = LAST_LINE - line; //row 1 is at the bottom
      Console.SetCursorPosition(column * cellWidth + columnOffset, line * 2 + lineOffset);
      piece.Render();
    }
    #endregion
  }
}
