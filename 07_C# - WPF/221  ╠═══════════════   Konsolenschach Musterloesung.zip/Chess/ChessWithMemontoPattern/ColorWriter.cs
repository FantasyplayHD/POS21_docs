﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessWithMemontoPattern
{
  public class ColorWriter
  {
    public ConsoleColor BackgroundColor { get; set; } = ConsoleColor.Black;
    public ConsoleColor ForegroundColor { get; set; } = ConsoleColor.White;
    //public void Write(object text)
    //{
    //  var origColBg = Console.BackgroundColor;
    //  var origColFg = Console.ForegroundColor;
    //  Console.BackgroundColor = BackgroundColor;
    //  Console.ForegroundColor = ForegroundColor;
    //  Console.Write(text);
    //  Console.BackgroundColor = origColBg;
    //  Console.ForegroundColor = origColFg;
    //}
    //public void WriteLine(object text)
    //{
    //  var origColBg = Console.BackgroundColor;
    //  var origColFg = Console.ForegroundColor;
    //  Console.BackgroundColor = BackgroundColor;
    //  Console.ForegroundColor = ForegroundColor;
    //  Console.WriteLine(text);
    //  Console.BackgroundColor = origColBg;
    //  Console.ForegroundColor = origColFg;
    //}

    //let's keep things DRY
    public void Write(object text) => WriteImpl(text, Console.Write);
    public void WriteLine(object text) => WriteImpl(text, Console.WriteLine);
    private void WriteImpl(object text, Action<object> writer)
    {
      //var origColBg = Console.BackgroundColor;
      //var origColFg = Console.ForegroundColor;
      Console.BackgroundColor = BackgroundColor;
      Console.ForegroundColor = ForegroundColor;
      writer(text);
      //Console.BackgroundColor = origColBg;
      //Console.ForegroundColor = origColFg;
      Console.ResetColor();
    }
  }
}
