﻿using System;

namespace ChessWithMemontoPattern
{
  internal class ImpossibleMoveException : ApplicationException
  {
    public ImpossibleMoveException(string msg)
      : base(msg)
    { }
  }
}
