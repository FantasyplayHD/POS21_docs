﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessWithMemontoPattern
{
  public class MoveTester
  {
    private readonly ColorWriter writer = new ColorWriter { BackgroundColor = ConsoleColor.Red };
    private bool allOk = true;
    private readonly ChessBoard board;
    public MoveTester()
    {
      board = new ChessBoard().Init();
      board.Move("e2-e4");
      board.Move("e7-e5");
      board.Move("d2-d4");
      board.Move("g7-g6");
      board.Move("b1-c3");
      board.Move("g8-f6");
    }
    public bool Test()
    {
      TestPawnMoves();
      TestRookMoves();
      TestBishopMoves();
      TestQueenMoves();
      TestKingMoves();
      return allOk;
    }

    private void TestKingMoves()
    {
      TestSingleMove(5, 1, 4, 2, true);
      TestSingleMove(5, 1, 5, 2, true);
      TestSingleMove(5, 1, 5, 3, false);
    }

    private void TestQueenMoves()
    {
      TestSingleMove(4, 1, 4, 2, true);
      TestSingleMove(4, 1, 5, 2, true);
      TestSingleMove(4, 1, 8, 5, true);
      TestSingleMove(4, 1, 1, 4, false);
    }

    private void TestBishopMoves()
    {
      TestSingleMove(3, 1, 2, 1, false);
      TestSingleMove(3, 1, 4, 2, true);
      TestSingleMove(3, 1, 5, 3, true);
      TestSingleMove(3, 1, 6, 4, true);
      TestSingleMove(3, 1, 1, 3, false);
      TestSingleMove(6, 8, 8, 6, true);
      TestSingleMove(3, 8, 1, 6, false);
    }

    private void TestRookMoves()
    {
      TestSingleMove(1, 1, 2, 1, true);
      TestSingleMove(1, 1, 1, 3, false);
    }

    private void TestPawnMoves()
    {
      TestSingleMove(3, 2, 3, 4, false);
      TestSingleMove(3, 2, 3, 3, false);
      TestSingleMove(4, 4, 4, 5, true); //move forward
      TestSingleMove(4, 4, 4, 6, false);//move 2 forward when not on baseline
      TestSingleMove(4, 4, 3, 5, false);//beat on empty field
      TestSingleMove(4, 4, 5, 5, true); //beat other figure
      TestSingleMove(1, 2, 1, 3, true); //move 1 forward when on baseline
      TestSingleMove(1, 2, 1, 4, true); //move 2 forward when on baseline
      TestSingleMove(1, 2, 1, 5, false);
    }

    private void TestSingleMove(int columnFrom, int lineFrom, int columnTo, int lineTo, bool expected)
    {
      var chessPiece = board.GetPieceAtPosition(columnFrom, lineFrom);
      bool actual = chessPiece.CanMove(columnTo, lineTo, board);
      if (actual == expected) return;
      string infix = actual ? " " : " not ";
      DisplayError($"{chessPiece} at {columnFrom}/{lineFrom} should{infix}be able to move to {columnTo}/{lineTo}");
    }

    private void DisplayError(string msg)
    {
      allOk = false;
      writer.WriteLine($"Test-Error: {msg.PadLeft(10, '*')}");
    }
  }
}
