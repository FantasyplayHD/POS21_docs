﻿namespace RabbitLib;

public class Gun
{
  private int _ammo = 3;
  public void Recharge() => _ammo = 3;
  public bool HasAmmo => _ammo > 0;
  public void FireAt(Rabbit rabbit)
  {
    if (!HasAmmo) return;
    if (rabbit.IsDodging) rabbit.Miss();
    else rabbit.Hit();
    _ammo--;
  }
}
