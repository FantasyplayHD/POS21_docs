﻿namespace RabbitLib;

public class Rabbit
{
  public void Dodge() => IsDodging = true;
  public void Hit() => IsDead = true;
  public void Miss() => IsDodging = false;
  public bool IsDodging { get; private set; }
  public bool IsDead { get; private set; }
}

